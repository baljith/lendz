<?php
get_header(); ?>
	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">
<!-- *************************************************** GET PAGE CONTENT OF BLOG PAGE *********************************************************** -->		

<style type="text/css">
#main > .vc_row { background: url(<?php echo $featured_img_url; ?>); background-size: cover; background-repeat: no-repeat;  }
</style>
	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">
			<div id="primary" class="content-area">
				<main id="main" class="site-main" role="main">

					<section class="error-404 not-found">
					<center>
						<img src="<?php echo get_template_directory_uri(); ?>/images/cYQgGcOanBA.png" style="margin-top: 130px;padding-bottom: 30px;">
					</center> 

				</main><!-- .site-main -->
			</div><!-- .content-area -->

<?php get_footer(); ?>
