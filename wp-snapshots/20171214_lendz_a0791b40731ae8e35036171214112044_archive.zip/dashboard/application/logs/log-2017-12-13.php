<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-13 04:34:53 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\lendz\dashboard\application\views\admin\product_view.php 100
ERROR - 2017-12-13 04:35:08 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\lendz\dashboard\application\views\admin\product_view.php 100
ERROR - 2017-12-13 04:37:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-13 04:37:38 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\lendz\dashboard\application\views\admin\product_view.php 263
