<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-10-24 05:48:32 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`) VALUES (NULL, 1000, '2017-10-24 05:48:32', 1, 'sub_BcTf9Ddr1dPRT6', 'cus_BbTX8zb6Xm5O98', '8')
ERROR - 2017-10-24 05:49:12 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`) VALUES (NULL, 1000, '2017-10-24 05:49:12', 1, 'sub_BcTilS0sOmaYg8', 'cus_BbSrbYVAt9mYkM', '8')
ERROR - 2017-10-24 05:49:25 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`) VALUES (NULL, 1000, '2017-10-24 05:49:25', 1, 'sub_BcThNSOAuKdTWl', 'cus_BbTX8zb6Xm5O98', '8')
ERROR - 2017-10-24 05:51:14 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`) VALUES (NULL, 1000, '2017-10-24 05:51:14', 1, 'sub_BcTmh06cXV9A1e', 'cus_BbTX8zb6Xm5O98', '8')
ERROR - 2017-10-24 05:51:58 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`) VALUES (NULL, 1000, '2017-10-24 05:51:58', 1, 'sub_BcTnKW8oFDkctw', 'cus_BbTcwAleJX0U8R', '8')
ERROR - 2017-10-24 05:52:23 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`) VALUES (NULL, 1000, '2017-10-24 05:52:23', 1, 'sub_BcTlTCBhmmLGSs', 'cus_BbTX8zb6Xm5O98', '8')
ERROR - 2017-10-24 05:59:13 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`) VALUES (NULL, 1000, '2017-10-24 05:59:13', 1, 'sub_BcTvhtph8LBsKI', 'cus_BbTX8zb6Xm5O98', '8')
ERROR - 2017-10-24 06:29:47 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`) VALUES (NULL, 1000, '2017-10-24 06:29:47', 1, 'sub_BcTilS0sOmaYg8', 'cus_BbSrbYVAt9mYkM', '8')
ERROR - 2017-10-24 06:53:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 06:53:04 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) D:\xampp\htdocs\truckapp\dashboard\application\controllers\Profile.php 93
ERROR - 2017-10-24 06:57:34 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`) VALUES (NULL, 1000, '2017-10-24 06:57:34', 1, 'sub_BcTlTCBhmmLGSs', 'cus_BbTX8zb6Xm5O98', '8')
ERROR - 2017-10-24 07:01:24 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`) VALUES (NULL, 1000, '2017-10-24 07:01:24', 1, 'sub_BcTf9Ddr1dPRT6', 'cus_BbTX8zb6Xm5O98', '8')
ERROR - 2017-10-24 07:15:12 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`) VALUES (NULL, 1000, '2017-10-24 07:15:12', 1, 'sub_BcThNSOAuKdTWl', 'cus_BbTX8zb6Xm5O98', '8')
ERROR - 2017-10-24 07:16:46 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`) VALUES (NULL, 1000, '2017-10-24 07:16:46', 1, 'sub_BcTnKW8oFDkctw', 'cus_BbTcwAleJX0U8R', '8')
ERROR - 2017-10-24 07:17:16 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`) VALUES (NULL, 1000, '2017-10-24 07:17:16', 1, 'sub_BcTmh06cXV9A1e', 'cus_BbTX8zb6Xm5O98', '8')
ERROR - 2017-10-24 07:18:24 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`) VALUES (NULL, 1000, '2017-10-24 07:18:24', 1, 'sub_BcTilS0sOmaYg8', 'cus_BbSrbYVAt9mYkM', '8')
ERROR - 2017-10-24 07:25:49 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-10-24 07:25:49', 1, 'sub_BcTvhtph8LBsKI', 'cus_BbTX8zb6Xm5O98', NULL, 0)
ERROR - 2017-10-24 07:28:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 07:28:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 07:28:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 07:28:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 07:28:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 07:29:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 07:29:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 07:29:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 07:29:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 07:29:25 --> Severity: Warning --> date() expects parameter 2 to be long, string given D:\xampp\htdocs\truckapp\dashboard\application\views\admin\payment_info.php 125
ERROR - 2017-10-24 07:29:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 07:30:52 --> Severity: Warning --> date() expects parameter 2 to be long, string given D:\xampp\htdocs\truckapp\dashboard\application\views\admin\payment_info.php 125
ERROR - 2017-10-24 07:30:52 --> Severity: Warning --> date() expects parameter 2 to be long, string given D:\xampp\htdocs\truckapp\dashboard\application\views\admin\payment_info.php 125
ERROR - 2017-10-24 07:30:52 --> Severity: Warning --> date() expects parameter 2 to be long, string given D:\xampp\htdocs\truckapp\dashboard\application\views\admin\payment_info.php 125
ERROR - 2017-10-24 07:30:52 --> Severity: Warning --> date() expects parameter 2 to be long, string given D:\xampp\htdocs\truckapp\dashboard\application\views\admin\payment_info.php 125
ERROR - 2017-10-24 07:30:53 --> Severity: Warning --> date() expects parameter 2 to be long, string given D:\xampp\htdocs\truckapp\dashboard\application\views\admin\payment_info.php 125
ERROR - 2017-10-24 07:30:53 --> Severity: Warning --> date() expects parameter 2 to be long, string given D:\xampp\htdocs\truckapp\dashboard\application\views\admin\payment_info.php 125
ERROR - 2017-10-24 07:31:18 --> Severity: Warning --> date() expects parameter 2 to be long, string given D:\xampp\htdocs\truckapp\dashboard\application\views\admin\payment_info.php 125
ERROR - 2017-10-24 07:33:58 --> Query error: Column 'Plan_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES ('97', 14000, '2017-10-24 07:33:58', 1, 'sub_BdeDWxNK6zL1Gv', 'cus_BdeDVoqk31TdPy', NULL, 0)
ERROR - 2017-10-24 07:34:33 --> Severity: Warning --> date() expects parameter 2 to be long, string given D:\xampp\htdocs\truckapp\dashboard\application\views\admin\payment_info.php 125
ERROR - 2017-10-24 07:39:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 07:53:28 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-10-24 07:53:28', 1, 'sub_BcTilS0sOmaYg8', 'cus_BbSrbYVAt9mYkM', '8', 0)
ERROR - 2017-10-24 07:55:06 --> Severity: Warning --> date() expects parameter 2 to be long, string given D:\xampp\htdocs\truckapp\dashboard\application\views\admin\payment_info.php 125
ERROR - 2017-10-24 07:56:09 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-10-24 07:56:09', 1, 'sub_BcTf9Ddr1dPRT6', 'cus_BbTX8zb6Xm5O98', '8', 0)
ERROR - 2017-10-24 08:01:24 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-10-24 08:01:24', 1, 'sub_BcTmh06cXV9A1e', 'cus_BbTX8zb6Xm5O98', '8', 0)
ERROR - 2017-10-24 08:01:25 --> Severity: Warning --> date() expects parameter 2 to be long, string given D:\xampp\htdocs\truckapp\dashboard\application\views\admin\payment_info.php 125
ERROR - 2017-10-24 08:01:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 08:03:29 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-10-24 08:03:29', 1, 'sub_BcTnKW8oFDkctw', 'cus_BbTcwAleJX0U8R', '8', 0)
ERROR - 2017-10-24 08:04:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 08:07:59 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 14000, '2017-10-24 08:07:59', 1, 'sub_BdeDWxNK6zL1Gv', 'cus_BdeDVoqk31TdPy', '4', 0)
ERROR - 2017-10-24 08:10:20 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-10-24 08:10:20', 1, 'sub_BcTlTCBhmmLGSs', 'cus_BbTX8zb6Xm5O98', '8', 0)
ERROR - 2017-10-24 08:11:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 08:12:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 08:18:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 08:20:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 08:22:40 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-10-24 08:22:40', 1, 'sub_BcThNSOAuKdTWl', 'cus_BbTX8zb6Xm5O98', '8', 0)
ERROR - 2017-10-24 08:24:53 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-10-24 08:24:53', 1, 'sub_BcTvhtph8LBsKI', 'cus_BbTX8zb6Xm5O98', '8', 0)
ERROR - 2017-10-24 08:31:11 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-10-24 08:31:11', 1, 'sub_BcTilS0sOmaYg8', 'cus_BbSrbYVAt9mYkM', '8', 0)
ERROR - 2017-10-24 08:31:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 08:37:24 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-10-24 08:37:24', 1, 'sub_BcTf9Ddr1dPRT6', 'cus_BbTX8zb6Xm5O98', '8', 0)
ERROR - 2017-10-24 08:39:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 08:44:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 08:45:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 08:47:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 08:53:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 08:55:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 08:58:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 08:58:07 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-10-24 08:58:07', 1, 'sub_BcTlTCBhmmLGSs', 'cus_BbTX8zb6Xm5O98', '8', 0)
ERROR - 2017-10-24 09:01:57 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-10-24 09:01:57', 1, 'sub_BcTmh06cXV9A1e', 'cus_BbTX8zb6Xm5O98', '8', 0)
ERROR - 2017-10-24 09:04:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 09:05:15 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-10-24 09:05:15', 1, 'sub_BcTnKW8oFDkctw', 'cus_BbTcwAleJX0U8R', '8', 0)
ERROR - 2017-10-24 09:11:23 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 14000, '2017-10-24 09:11:23', 1, 'sub_BdeDWxNK6zL1Gv', 'cus_BdeDVoqk31TdPy', '4', 0)
ERROR - 2017-10-24 09:11:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 09:12:45 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-10-24 09:12:45', 1, 'sub_BcThNSOAuKdTWl', 'cus_BbTX8zb6Xm5O98', '8', 0)
ERROR - 2017-10-24 09:22:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 09:23:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 09:23:29 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::where() D:\xampp\htdocs\truckapp\dashboard\application\controllers\Profile.php 324
ERROR - 2017-10-24 09:24:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 09:24:17 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::order_by() D:\xampp\htdocs\truckapp\dashboard\application\controllers\Profile.php 324
ERROR - 2017-10-24 09:27:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 09:27:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 09:29:24 --> Query error: Column 'User_Id' in where clause is ambiguous - Invalid query: SELECT `t`.*, `p`.`Package_Name`, `p`.`Package_Price`
FROM `ci_transactions` `t`
LEFT JOIN `ci_packages` `p` ON `p`.`Package_Id`=`t`.`Plan_Id`
LEFT JOIN `ci_subscriptions` `s` ON `s`.`Subs_Id`=`t`.`Subs_Id`
WHERE `User_Id` = '98'
ORDER BY `t`.`T_Id` DESC
ERROR - 2017-10-24 09:37:18 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-10-24 09:37:18', 1, 'sub_BcTnKW8oFDkctw', 'cus_BbTcwAleJX0U8R', '8', 0)
ERROR - 2017-10-24 09:37:37 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-10-24 09:37:37', 1, 'sub_BcTf9Ddr1dPRT6', 'cus_BbTX8zb6Xm5O98', '8', 0)
ERROR - 2017-10-24 09:40:41 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-10-24 09:40:41', 1, 'sub_BcTlTCBhmmLGSs', 'cus_BbTX8zb6Xm5O98', '8', 0)
ERROR - 2017-10-24 09:45:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 09:45:16 --> Severity: Parsing Error --> syntax error, unexpected ';' D:\xampp\htdocs\truckapp\dashboard\application\views\admin\transactions_info.php 34
ERROR - 2017-10-24 09:53:08 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-10-24 09:53:08', 1, 'sub_BcTvhtph8LBsKI', 'cus_BbTX8zb6Xm5O98', '8', 0)
ERROR - 2017-10-24 09:53:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 09:54:50 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-10-24 09:54:50', 1, 'sub_BcThNSOAuKdTWl', 'cus_BbTX8zb6Xm5O98', '8', 0)
ERROR - 2017-10-24 09:55:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 09:59:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 10:01:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 10:02:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 10:05:44 --> Severity: Warning --> date() expects parameter 2 to be long, string given D:\xampp\htdocs\truckapp\dashboard\application\views\admin\payment_info.php 129
ERROR - 2017-10-24 10:08:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 10:08:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:08:50 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC), expecting '(' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 50
ERROR - 2017-10-24 10:08:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:08:50 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC), expecting '(' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 50
ERROR - 2017-10-24 10:08:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:08:50 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC), expecting '(' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 50
ERROR - 2017-10-24 10:08:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:08:50 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC), expecting '(' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 50
ERROR - 2017-10-24 10:08:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:08:51 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC), expecting ';' or '{' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 50
ERROR - 2017-10-24 10:08:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:08:51 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC), expecting ';' or '{' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 50
ERROR - 2017-10-24 10:08:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:08:52 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC), expecting ';' or '{' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 50
ERROR - 2017-10-24 10:08:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:08:52 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC), expecting ';' or '{' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 50
ERROR - 2017-10-24 10:09:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:09:17 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 59
ERROR - 2017-10-24 10:09:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:09:17 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 59
ERROR - 2017-10-24 10:09:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:09:17 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 59
ERROR - 2017-10-24 10:09:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:09:17 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 59
ERROR - 2017-10-24 10:09:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:09:17 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 59
ERROR - 2017-10-24 10:09:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:09:17 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 59
ERROR - 2017-10-24 10:09:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:09:18 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 59
ERROR - 2017-10-24 10:09:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:09:18 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 59
ERROR - 2017-10-24 10:10:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:10:08 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 54
ERROR - 2017-10-24 10:10:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:10:08 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 54
ERROR - 2017-10-24 10:10:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:10:08 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 54
ERROR - 2017-10-24 10:10:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:10:08 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 54
ERROR - 2017-10-24 10:10:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:10:09 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 54
ERROR - 2017-10-24 10:10:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:10:09 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 54
ERROR - 2017-10-24 10:10:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:10:10 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 54
ERROR - 2017-10-24 10:10:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:10:10 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 54
ERROR - 2017-10-24 10:10:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 10:10:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:10:11 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 54
ERROR - 2017-10-24 10:10:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:10:11 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 54
ERROR - 2017-10-24 10:10:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:10:11 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 54
ERROR - 2017-10-24 10:10:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:10:11 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 54
ERROR - 2017-10-24 10:11:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 10:14:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:09 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:09 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:10 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:10 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:11 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:11 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 10:14:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:11 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:11 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:12 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:12 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:13 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:13 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:14 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:14 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:14 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:14 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:14 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:16 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:16 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:17 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:17 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:17 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:17 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:17 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:19 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:19 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:20 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:20 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:20 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:20 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:22 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:22 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:23 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:23 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:23 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:23 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:25 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:25 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:26 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:26 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:26 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:14:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:14:26 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\truckapp\dashboard\application\libraries\Auth.php 55
ERROR - 2017-10-24 10:17:19 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 14000, '2017-10-24 10:17:19', 1, 'sub_BdeDWxNK6zL1Gv', 'cus_BdeDVoqk31TdPy', '4', 0)
ERROR - 2017-10-24 10:21:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 10:22:42 --> Severity: Warning --> date() expects parameter 2 to be long, string given D:\xampp\htdocs\truckapp\dashboard\application\views\admin\payment_info.php 129
ERROR - 2017-10-24 10:25:03 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-10-24 10:25:03', 1, 'sub_BcTmh06cXV9A1e', 'cus_BbTX8zb6Xm5O98', '8', 0)
ERROR - 2017-10-24 10:25:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 10:27:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 10:27:57 --> Severity: Warning --> date() expects parameter 2 to be long, string given D:\xampp\htdocs\truckapp\dashboard\application\views\admin\payment_info.php 129
ERROR - 2017-10-24 10:31:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 10:31:36 --> Severity: Warning --> date() expects parameter 2 to be long, string given D:\xampp\htdocs\truckapp\dashboard\application\views\admin\payment_info.php 129
ERROR - 2017-10-24 10:32:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 10:40:19 --> Query error: Column 'User_Id' in group statement is ambiguous - Invalid query: SELECT `sb`.`Created_Date`, CONCAT(u.User_First_Name,' ',u.User_Last_Name) As User_Full_Name, `p`.`Package_Name`, `p`.`Package_Price`, `sb`.`Status`, `sb`.`End_At`, `sb`.`Subs_Id`
FROM `ci_subscriptions` `sb`
LEFT JOIN `ci_packages` `p` ON `p`.`Package_Id`=`sb`.`Plan_Id`
INNER JOIN `ci_users` `u` ON `u`.`User_Id`=`sb`.`User_Id`
WHERE ( CONCAT(u.User_First_Name,' ',u.User_Last_Name) LIKE '%%' OR `p`.`Package_Name` LIKE '%%'  )
GROUP BY `User_Id`
ORDER BY `sb`.`Created_Date` DESC
 LIMIT 10
ERROR - 2017-10-24 10:40:58 --> Query error: Unknown column 'T_Id' in 'order clause' - Invalid query: SELECT `sb`.`Created_Date`, CONCAT(u.User_First_Name,' ',u.User_Last_Name) As User_Full_Name, `p`.`Package_Name`, `p`.`Package_Price`, `sb`.`Status`, `sb`.`End_At`, `sb`.`Subs_Id`
FROM `ci_subscriptions` `sb`
LEFT JOIN `ci_packages` `p` ON `p`.`Package_Id`=`sb`.`Plan_Id`
INNER JOIN `ci_users` `u` ON `u`.`User_Id`=`sb`.`User_Id`
WHERE ( CONCAT(u.User_First_Name,' ',u.User_Last_Name) LIKE '%%' OR `p`.`Package_Name` LIKE '%%'  )
GROUP BY `sb`.`User_Id`
ORDER BY `T_Id` DESC, `sb`.`Created_Date` DESC
 LIMIT 10
ERROR - 2017-10-24 10:48:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 10:50:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 10:54:51 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 14000, '2017-10-24 10:54:51', 1, 'sub_BdeDWxNK6zL1Gv', 'cus_BdeDVoqk31TdPy', '4', 0)
ERROR - 2017-10-24 10:55:07 --> Severity: Warning --> date() expects parameter 2 to be long, string given D:\xampp\htdocs\truckapp\dashboard\application\views\admin\payment_info.php 129
ERROR - 2017-10-24 10:56:58 --> Severity: Warning --> date() expects parameter 2 to be long, string given D:\xampp\htdocs\truckapp\dashboard\application\views\admin\payment_info.php 129
ERROR - 2017-10-24 10:58:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:58:57 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) D:\xampp\htdocs\truckapp\dashboard\application\views\admin\payment_info.php 133
ERROR - 2017-10-24 10:59:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 10:59:08 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) D:\xampp\htdocs\truckapp\dashboard\application\views\admin\payment_info.php 132
ERROR - 2017-10-24 11:02:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 11:09:21 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-10-24 11:09:21', 1, 'sub_BcTvhtph8LBsKI', 'cus_BbTX8zb6Xm5O98', '8', 0)
ERROR - 2017-10-24 11:16:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 11:19:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 11:22:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 11:29:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 11:34:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 11:35:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 12:09:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 12:18:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-10-24 12:30:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-24 12:30:48 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) D:\xampp\htdocs\truckapp\dashboard\application\views\admin\transactions_info.php 32
ERROR - 2017-10-24 13:46:46 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-10-24 13:46:46', 1, 'sub_BbTsGys2ZBYJbz', 'cus_BbRZ9qgztwNzjO', '8', 0)
ERROR - 2017-10-24 14:56:37 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-10-24 14:56:37', 1, 'sub_BbTsGys2ZBYJbz', 'cus_BbRZ9qgztwNzjO', '8', 0)
ERROR - 2017-10-24 15:32:10 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-10-24 15:32:10', 1, 'sub_BbTsGys2ZBYJbz', 'cus_BbRZ9qgztwNzjO', '8', 0)
ERROR - 2017-10-24 16:46:06 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-10-24 16:46:06', 1, 'sub_BbTsGys2ZBYJbz', 'cus_BbRZ9qgztwNzjO', '8', 0)
ERROR - 2017-10-24 17:17:44 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-10-24 17:17:44', 1, 'sub_BbTsGys2ZBYJbz', 'cus_BbRZ9qgztwNzjO', '8', 0)
