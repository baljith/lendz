<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-11-25 06:23:28 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'tooltruc_wp364'@'localhost' (using password: YES) D:\xampp\htdocs\lendz\dashboard\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-11-25 06:23:28 --> Unable to connect to the database
ERROR - 2017-11-25 06:33:53 --> Could not find the language line "error_title"
ERROR - 2017-11-25 06:38:25 --> Could not find the language line "error_title"
ERROR - 2017-11-25 08:01:53 --> Query error: Unknown column 'id' in 'where clause' - Invalid query: SELECT *
FROM `ci_packages`
WHERE `id` = '1'
ERROR - 2017-11-25 09:39:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3721) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-11-25 09:39:58 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\lendz\dashboard\application\views\admin\category_add.php 47
ERROR - 2017-11-25 09:50:43 --> Query error: Unknown column 'u.User_Franchise_Name' in 'field list' - Invalid query: SELECT `t`.*, `u`.`User_Id`, `u`.`Username`, `u`.`Role`, `u`.`User_First_Name`, `u`.`User_Last_Name`, `u`.`User_Franchise_Name`, `u`.`User_Buisness_Address`, `u`.`User_Email`
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
WHERE `t`.`User_Role` = '1'
AND `t`.`Type` = 'needed'
ORDER BY `t`.`Created_Date` DESC
ERROR - 2017-11-25 10:26:26 --> Query error: Unknown column 'Created_At' in 'field list' - Invalid query: INSERT INTO `ci_categories` (`name`, `created`, `Created_At`, `User_Image`) VALUES ('abc', '2017-11-25 10:26:26', '2017-11-25 10:26:26', 'category_image_1511605586.png')
ERROR - 2017-11-25 10:27:07 --> Query error: Unknown column 'User_Image' in 'field list' - Invalid query: INSERT INTO `ci_categories` (`name`, `created`, `User_Image`) VALUES ('sadasd', '2017-11-25 10:27:07', 'category_image_1511605627.png')
ERROR - 2017-11-25 10:45:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3721) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-11-25 10:45:29 --> Severity: Parsing Error --> syntax error, unexpected ')' D:\xampp\htdocs\lendz\dashboard\application\views\admin\category_add.php 48
ERROR - 2017-11-25 10:59:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3721) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-11-25 10:59:30 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\lendz\dashboard\application\views\admin\category_add.php 78
ERROR - 2017-11-25 11:18:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3721) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-11-25 11:18:05 --> Severity: Parsing Error --> syntax error, unexpected '<' D:\xampp\htdocs\lendz\dashboard\application\views\admin\category_add.php 88
