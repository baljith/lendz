<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-09 05:51:48 --> Query error: Unknown column 'ci_products.Product_Price' in 'field list' - Invalid query: SELECT `ci_products`.`Id`, `ci_products`.`Product_Name`, `ci_products`.`Product_Price`, `ci_products`.`Status`, `ci_users`.`Username`, `ci_categories`.`Name`
FROM `ci_products`
LEFT JOIN `ci_users` ON `ci_users`.`User_Id` = `ci_products`.`User_Id`
LEFT JOIN `ci_categories` ON `ci_categories`.`Id` = `ci_products`.`Category_Id`
ERROR - 2017-12-09 05:52:59 --> Query error: Unknown column 'ci_products.Product_Price' in 'field list' - Invalid query: SELECT `ci_products`.`Id`, `ci_products`.`Product_Name`, `ci_products`.`Product_Price`, `ci_products`.`Status`, `ci_users`.`Username`, `ci_categories`.`Name`
FROM `ci_products`
LEFT JOIN `ci_users` ON `ci_users`.`User_Id` = `ci_products`.`User_Id`
LEFT JOIN `ci_categories` ON `ci_categories`.`Id` = `ci_products`.`Category_Id`
ERROR - 2017-12-09 05:54:42 --> Query error: Unknown column 'ci_products.Product_Price' in 'field list' - Invalid query: SELECT `ci_products`.`Id`, `ci_products`.`Product_Name`, `ci_products`.`Product_Price`, `ci_products`.`Product_Description`, `ci_products`.`Status`, `ci_users`.`Username`, `ci_users`.`User_Email`, `ci_categories`.`Name`
FROM `ci_products`
LEFT JOIN `ci_users` ON `ci_users`.`User_Id` = `ci_products`.`User_Id`
LEFT JOIN `ci_categories` ON `ci_categories`.`Id` = `ci_products`.`Category_Id`
WHERE `ci_products`.`Id` = 3
ERROR - 2017-12-09 09:47:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-09 09:47:25 --> Severity: Parsing Error --> syntax error, unexpected ''data'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\lendz\dashboard\application\models\Common_model.php 430
ERROR - 2017-12-09 09:47:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-09 09:47:25 --> Severity: Parsing Error --> syntax error, unexpected ''data'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\lendz\dashboard\application\models\Common_model.php 430
ERROR - 2017-12-09 09:47:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-09 09:47:28 --> Severity: Parsing Error --> syntax error, unexpected ''data'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\lendz\dashboard\application\models\Common_model.php 430
ERROR - 2017-12-09 09:47:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-09 09:47:28 --> Severity: Parsing Error --> syntax error, unexpected ''data'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\lendz\dashboard\application\models\Common_model.php 430
ERROR - 2017-12-09 09:47:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-09 09:47:31 --> Severity: Parsing Error --> syntax error, unexpected ''data'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\lendz\dashboard\application\models\Common_model.php 430
ERROR - 2017-12-09 09:47:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-09 09:47:31 --> Severity: Parsing Error --> syntax error, unexpected ''data'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\lendz\dashboard\application\models\Common_model.php 430
ERROR - 2017-12-09 09:47:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-09 09:47:34 --> Severity: Parsing Error --> syntax error, unexpected ''data'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\lendz\dashboard\application\models\Common_model.php 430
ERROR - 2017-12-09 09:47:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-09 09:47:34 --> Severity: Parsing Error --> syntax error, unexpected ''data'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\lendz\dashboard\application\models\Common_model.php 430
ERROR - 2017-12-09 09:47:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-09 09:47:37 --> Severity: Parsing Error --> syntax error, unexpected ''data'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\lendz\dashboard\application\models\Common_model.php 430
ERROR - 2017-12-09 09:47:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-09 09:47:37 --> Severity: Parsing Error --> syntax error, unexpected ''data'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\lendz\dashboard\application\models\Common_model.php 430
ERROR - 2017-12-09 09:47:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-09 09:47:40 --> Severity: Parsing Error --> syntax error, unexpected ''data'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\lendz\dashboard\application\models\Common_model.php 430
ERROR - 2017-12-09 09:47:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-09 09:47:40 --> Severity: Parsing Error --> syntax error, unexpected ''data'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\lendz\dashboard\application\models\Common_model.php 430
ERROR - 2017-12-09 09:47:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-09 09:47:40 --> Severity: Parsing Error --> syntax error, unexpected ''data'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\lendz\dashboard\application\models\Common_model.php 430
ERROR - 2017-12-09 10:46:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY Created_Date desc' at line 4 - Invalid query: SELECT p.*,
            ( 3959 * acos ( cos ( radians("") ) * cos( radians( `p`.`Latitude` ) ) * cos( radians( `p`.`Longitude` ) - radians("") ) + sin ( radians("") ) * sin( radians( `p`.`Latitude` ) ) ) ) AS distance
            FROM products p
            WHERE Booking_Status="Available"   AND User_Id="86"  LIMIT 10,0 ORDER BY Created_Date desc
ERROR - 2017-12-09 10:57:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'HAVING distance < "142"  AND User_Id="86"  ORDER BY Created_Date desc LIMIT 10' at line 4 - Invalid query: SELECT p.*,
            ( 3959 * acos ( cos ( radians("30.905865") ) * cos( radians( `p`.`Latitude` ) ) * cos( radians( `p`.`Longitude` ) - radians("75.836304") ) + sin ( radians("30.905865") ) * sin( radians( `p`.`Latitude` ) ) ) ) AS distance
            FROM ci_products p
            WHERE Booking_Status="Available"   AND HAVING distance < "142"  AND User_Id="86"  ORDER BY Created_Date desc LIMIT 10
ERROR - 2017-12-09 11:34:46 --> Query error: FUNCTION c.Name does not exist. Check the 'Function Name Parsing and Resolution' section in the Reference Manual - Invalid query: SELECT p.*,c.Name
            ( 3959 * acos ( cos ( radians("") ) * cos( radians( `p`.`Latitude` ) ) * cos( radians( `p`.`Longitude` ) - radians("") ) + sin ( radians("") ) * sin( radians( `p`.`Latitude` ) ) ) ) AS distance
            FROM ci_products p LEFT JOIN ci_categories c ON c.Id=p.Category_Id 
            WHERE Booking_Status="Available"   AND User_Id="86"  ORDER BY Created_Date desc LIMIT 10
ERROR - 2017-12-09 12:19:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-09 12:19:20 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' D:\xampp\htdocs\lendz\dashboard\application\views\admin\product_view.php 100
ERROR - 2017-12-09 12:24:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-09 12:24:29 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\lendz\dashboard\application\views\admin\product_view.php 260
ERROR - 2017-12-09 12:24:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-09 12:24:40 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\lendz\dashboard\application\views\admin\product_view.php 259
ERROR - 2017-12-09 12:25:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-09 12:25:07 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\lendz\dashboard\application\views\admin\product_view.php 259
ERROR - 2017-12-09 12:25:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-09 12:25:22 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\lendz\dashboard\application\views\admin\product_view.php 259
ERROR - 2017-12-09 12:25:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-09 12:25:45 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\lendz\dashboard\application\views\admin\product_view.php 259
ERROR - 2017-12-09 12:26:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-09 12:26:11 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\lendz\dashboard\application\views\admin\product_view.php 259
ERROR - 2017-12-09 12:26:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-09 12:26:24 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\xampp\htdocs\lendz\dashboard\application\views\admin\product_view.php 259
ERROR - 2017-12-09 12:32:04 --> Query error: Column 'Status' in where clause is ambiguous - Invalid query: SELECT p.*,c.Name,
            ( 3959 * acos ( cos ( radians("30.905865") ) * cos( radians( `p`.`Latitude` ) ) * cos( radians( `p`.`Longitude` ) - radians("75.836304") ) + sin ( radians("30.905865") ) * sin( radians( `p`.`Latitude` ) ) ) ) AS distance
            FROM ci_products p LEFT JOIN ci_categories c ON c.Id=p.Category_Id 
            WHERE Booking_Status="Available"   AND User_Id!="86" AND Booking_Status="Available" AND Status="Approved" ORDER BY Created_Date desc LIMIT 10
ERROR - 2017-12-09 12:34:20 --> Query error: Column 'Status' in where clause is ambiguous - Invalid query: SELECT p.*,c.Name,
            ( 3959 * acos ( cos ( radians("30.905865") ) * cos( radians( `p`.`Latitude` ) ) * cos( radians( `p`.`Longitude` ) - radians("75.836304") ) + sin ( radians("30.905865") ) * sin( radians( `p`.`Latitude` ) ) ) ) AS distance
            FROM ci_products p LEFT JOIN ci_categories c ON c.Id=p.Category_Id 
            WHERE Booking_Status="Available"   AND User_Id!="86" AND Booking_Status="Available" AND Status="Approved" ORDER BY Created_Date desc LIMIT 10
