<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-01 07:29:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'OR `Sent_By` =) AND `Last` = "1"
ORDER BY `M_Id` DESC
 LIMIT 10' at line 6 - Invalid query: SELECT `m`.*, `uf`.`User_First_Name` AS `From_User_First_Name`, `uf`.`User_Last_Name` AS `From_User_Last_Name`, `uf`.`User_Image` AS `From_User_Image`, `ut`.`User_First_Name` AS `To_User_First_Name`, `ut`.`User_Last_Name` AS `To_User_Last_Name`, `ut`.`User_Image` AS `To_User_Image`, `p`.`Product_Name`
FROM `ci_messages` `m`
LEFT JOIN `ci_users` `uf` ON `uf`.`User_Id`=`m`.`Sent_By`
LEFT JOIN `ci_users` `ut` ON `ut`.`User_Id`=`m`.`Sent_To`
LEFT JOIN `ci_products` `p` ON `p`.`Id`=`m`.`Thread`
WHERE (`Sent_To` = OR `Sent_By` =) AND `Last` = "1"
ORDER BY `M_Id` DESC
 LIMIT 10
ERROR - 2017-12-01 07:30:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'OR `Sent_By` =) AND `Last` = "1"
ORDER BY `M_Id` DESC
 LIMIT 10' at line 6 - Invalid query: SELECT `m`.*, `uf`.`User_First_Name` AS `From_User_First_Name`, `uf`.`User_Last_Name` AS `From_User_Last_Name`, `uf`.`User_Image` AS `From_User_Image`, `ut`.`User_First_Name` AS `To_User_First_Name`, `ut`.`User_Last_Name` AS `To_User_Last_Name`, `ut`.`User_Image` AS `To_User_Image`, `p`.`Product_Name`
FROM `ci_messages` `m`
LEFT JOIN `ci_users` `uf` ON `uf`.`User_Id`=`m`.`Sent_By`
LEFT JOIN `ci_users` `ut` ON `ut`.`User_Id`=`m`.`Sent_To`
LEFT JOIN `ci_products` `p` ON `p`.`Id`=`m`.`Thread`
WHERE (`Sent_To` = OR `Sent_By` =) AND `Last` = "1"
ORDER BY `M_Id` DESC
 LIMIT 10
ERROR - 2017-12-01 07:32:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'OR `Sent_By` =) AND `Last` = "1"
ORDER BY `M_Id` DESC
 LIMIT 10' at line 6 - Invalid query: SELECT `m`.*, `uf`.`User_First_Name` AS `From_User_First_Name`, `uf`.`User_Last_Name` AS `From_User_Last_Name`, `uf`.`User_Image` AS `From_User_Image`, `ut`.`User_First_Name` AS `To_User_First_Name`, `ut`.`User_Last_Name` AS `To_User_Last_Name`, `ut`.`User_Image` AS `To_User_Image`, `p`.`Product_Name`
FROM `ci_messages` `m`
LEFT JOIN `ci_users` `uf` ON `uf`.`User_Id`=`m`.`Sent_By`
LEFT JOIN `ci_users` `ut` ON `ut`.`User_Id`=`m`.`Sent_To`
LEFT JOIN `ci_products` `p` ON `p`.`Id`=`m`.`Thread`
WHERE (`Sent_To` = OR `Sent_By` =) AND `Last` = "1"
ORDER BY `M_Id` DESC
 LIMIT 10
ERROR - 2017-12-01 07:32:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'OR `Sent_By` =) AND `Last` = "1"
ORDER BY `M_Id` DESC
 LIMIT 10' at line 6 - Invalid query: SELECT `m`.*, `uf`.`User_First_Name` AS `From_User_First_Name`, `uf`.`User_Last_Name` AS `From_User_Last_Name`, `uf`.`User_Image` AS `From_User_Image`, `ut`.`User_First_Name` AS `To_User_First_Name`, `ut`.`User_Last_Name` AS `To_User_Last_Name`, `ut`.`User_Image` AS `To_User_Image`, `p`.`Product_Name`
FROM `ci_messages` `m`
LEFT JOIN `ci_users` `uf` ON `uf`.`User_Id`=`m`.`Sent_By`
LEFT JOIN `ci_users` `ut` ON `ut`.`User_Id`=`m`.`Sent_To`
LEFT JOIN `ci_products` `p` ON `p`.`Id`=`m`.`Thread`
WHERE (`Sent_To` = OR `Sent_By` =) AND `Last` = "1"
ORDER BY `M_Id` DESC
 LIMIT 10
ERROR - 2017-12-01 07:37:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'OR `Sent_By` =) AND `Last` = "1"
ORDER BY `M_Id` DESC
 LIMIT 10' at line 6 - Invalid query: SELECT `m`.*, `uf`.`User_First_Name` AS `From_User_First_Name`, `uf`.`User_Last_Name` AS `From_User_Last_Name`, `uf`.`User_Image` AS `From_User_Image`, `ut`.`User_First_Name` AS `To_User_First_Name`, `ut`.`User_Last_Name` AS `To_User_Last_Name`, `ut`.`User_Image` AS `To_User_Image`, `p`.`Product_Name`
FROM `ci_messages` `m`
LEFT JOIN `ci_users` `uf` ON `uf`.`User_Id`=`m`.`Sent_By`
LEFT JOIN `ci_users` `ut` ON `ut`.`User_Id`=`m`.`Sent_To`
LEFT JOIN `ci_products` `p` ON `p`.`Id`=`m`.`Thread`
WHERE (`Sent_To` = OR `Sent_By` =) AND `Last` = "1"
ORDER BY `M_Id` DESC
 LIMIT 10
ERROR - 2017-12-01 12:37:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` = '86'
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-12-01 12:40:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` = '86'
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
