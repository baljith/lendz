<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-07 06:20:13 --> Query error: Unknown column 'Product_Rent' in 'field list' - Invalid query: INSERT INTO `ci_users` (`Product_Rent`, `Product_Deposit`, `Product_Description`, `Category_Id`, `Latitude`, `Longitude`, `Location`, `User_Id`, `Created_Date`, `Status`) VALUES ('120', '160', 'Description Textarea', '5', 30.8452416, 75.6725826, 'Ludhiana Bus Stand, Mullanpur Dakha, Punjab, India', '85', '2017-12-07 06:20:13', 'Pending')
ERROR - 2017-12-07 06:38:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-07 06:38:14 --> Severity: Parsing Error --> syntax error, unexpected ';' D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Products.php 132
ERROR - 2017-12-07 06:38:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-07 06:38:23 --> Severity: Parsing Error --> syntax error, unexpected ';' D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Products.php 132
ERROR - 2017-12-07 06:38:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-07 06:38:51 --> Severity: Parsing Error --> syntax error, unexpected ';' D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Products.php 132
ERROR - 2017-12-07 06:51:44 --> Query error: Table 'technocr_lendz.ci_user_id' doesn't exist - Invalid query: INSERT INTO `ci_User_Id` (`Product_Id`, `Product_Image`, `Created_Date`) VALUES ('5', 'product_img1512629504.jpg', '2017-12-07 06:51:44')
ERROR - 2017-12-07 06:51:47 --> Query error: Table 'technocr_lendz.ci_user_id' doesn't exist - Invalid query: INSERT INTO `ci_User_Id` (`Product_Id`, `Product_Image`, `Created_Date`) VALUES ('5', 'product_img1512629507.jpg', '2017-12-07 06:51:47')
ERROR - 2017-12-07 13:54:37 --> Query error: Unknown column 'Is_Deleted' in 'where clause' - Invalid query: SELECT *
FROM `ci_products`
WHERE `User_Id` = '86'
AND `Is_Deleted` = '0'
ORDER BY `Created_Date` DESC
 LIMIT 10
