<?php 
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Config for the Plivo library
 */

//Dummy Credentials

// $config['PUBLISHABLE_KEY'] = 'pk_test_AExNYVSOYRXrdq6pmobbpWsu';
// $config['SECRET_KEY'] = 'sk_test_jmEMF0Bme6SYWVdz2Kl0JHNP';

//Live 
$config['PUBLISHABLE_KEY'] = 'pk_live_J7bH4mP9exIpLihgK9wuCuyD';
$config['SECRET_KEY'] = 'sk_live_Or8DUxUWnGCGqiG58KBOjkV8';
?>