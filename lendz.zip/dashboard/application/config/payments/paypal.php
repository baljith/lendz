<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

$config['paypal_api_username'] = "mohitp_api1.technocratshorizons.com";
$config['paypal_api_password'] = "5SYKZVEQYMF95FM8";
$config['paypal_api_signature'] = "An5ns1Kso7MWUdW4ErQKJJJ4qi4-AhU4Lk02m1-idvio9Lqot-oraGgH";
$config['paypal_api_endpoint'] = "https://api-3t.sandbox.paypal.com/nvp";
$config['paypal_api_version'] = "";
$config['paypal_api_service_description'] = "Service Description";
