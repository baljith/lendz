			<tr style="border-bottom:1px solid #eee;text-align:center;background:#141414;">
					<td>
						<table width="100%">
							<tbody>
								<tr style="text-align:center;">
									<td style="color:white;text-align: left;">
										contact@lendzapp.com
									</td>
									<td style="color:white;text-align: right">
										© Copyright <?php echo date('Y'); ?> LendzApp. 
									</td>
								</tr>								
							</tbody>
						</table>
					</td>
				</tr>
			</tbody>
		</table>		
	</body>
</html>