<div id="content" class="content">
	<div class="row">
		<div class="col-md-6 col-sm-6 col-lg-6 col-xs-12">
			    <span class="page-headers">Messages (Technicians) <span class=" label label-success">3 new messages</span></span>
				<ol class="breadcrumb">
					<li><a href="<?php echo base_url(); ?>">Home</a></li>
					<li class="active">Messages Technicians</li>
				</ol>
		</div>
		<div class="col-md-6 col-sm-6 col-lg-6 col-xs-12">
			<div class="pull-right">
				<button type="submit" class="btn btn-danger  btn-search"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> New Messsage</button>
			</div>
		</div>
	</div>	
</div>
<hr class="horizental_line">
<div id="content" class="content">
	<div class="search_form">
		<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 custom-padding-class">
          
           	<select data-style="btn-white" class="form-control selectpicker">
					<option>Filter By: All Time</option>
					<option>Demo 1</option>
			</select>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-6 col-xs-12">
			<div class="pull-right">
			    <button class="btn  refresh_btn" type="button">  <span class="glyphicon glyphicon-refresh"></span> Refresh </button>

			    <div class="btn-group">
					<button class="btn next_page-btn" type="button"> 
						<i class="fa fa-chevron-left" aria-hidden="true"></i>
					</button>
					<button class="btn next_page-btn" type="button"> <i class="fa fa-chevron-right" aria-hidden="true"></i>
	                </button>
                </div>
			</div>
		</div>
	</div>	   
</div>

<div class="clear-fix"></div>
<div id="content" class="content">
	<div class="row">
		<div class="col-md-12 col-sm-12 col-xs-12"> 
			<div class="total_msg_count">
					<big>1232 messages </big>
			</div> 	
			<div class="panel panel-inverse margin-b0">
			    <div class="panel-body active">
				  	<div class="col-md-1 col-sm-1 col-lg-1 col-xs-2">
				  		<div  class="circle-badge active">
	            				<strong>WS</strong>
	            				<span class="badge badge-inverse badge_circle">12</span>
	          			</div>
				  	</div>
				  	<div class="col-md-11 col-sm-11 col-lg-11 col-xs-10">
				  			<span class="page-headers">Sohan Dhainwal</span>
				  			<span class="msg_time date-time">
				  			  <i class="fa fa-clock-o" aria-hidden="true"></i>
	                           3:49pm 
	                        </span>
				  		<p>Using color to add meaning only provides a visual indication, which will not be conveyed to users of assistive technologies – such as screen readers. Ensure that information denoted by the color is either obvious from th</p>
				  	</div>
			    </div>
			</div>                
            <div class="panel panel-inverse margin-b0">
            	<div class="panel-body active">
				  	<div class="col-md-1 col-sm-1 col-lg-1 col-xs-2">
				  		<div  class="circle-badge active">
	            			<strong>WS</strong>
	            			<span class="badge badge-inverse badge_circle">12</span>
	          			</div>
				  	</div>
				  	<div class="col-md-11 col-sm-11 col-lg-11 col-xs-10">
				  		<span class="page-headers">Sohan Dhainwal</span>
				  		<span class="msg_time">
				  			  <i class="fa fa-clock-o" aria-hidden="true"></i>
	                           3:49pm 
	                    </span>
				  			<p>Using color to add meaning only provides a visual indication, which will not be conveyed to users of assistive technologies – such as screen readers. Ensure that information denoted by the color is either obvious from th</p>
				  	</div>
			    </div>     
            </div>
            <div class="panel panel-inverse margin-b0">
			    <div class="panel-body">
				  	<div class="col-md-1 col-sm-1 col-lg-1 col-xs-2">
				  		<div  class="circle-badge">
	            			<strong>S</strong>
	            			
	          			</div>
				  		</div>
				  		<div class="col-md-11 col-sm-11 col-lg-11 col-xs-10">
				  			<span class="page-headers">Sohan Dhainwal</span>
				  			<span class="msg_time">
				  			  <i class="fa fa-clock-o" aria-hidden="true"></i>
	                           3:49pm 
	                        </span>
				  			<p>Using color to add meaning only provides a visual indication, which will not be conveyed to users of assistive technologies – such as screen readers. Ensure that information denoted by the color is either obvious from th</p>
				  	</div>
			  </div>
			</div> 
			<div class="panel panel-inverse margin-b0">
			    <div class="panel-body">
				  	<div class="col-md-1 col-sm-1 col-lg-1 col-xs-2">
				  		<div  class="circle-badge">
	            				<strong>S</strong>
	            				
	          			</div>
				  	</div>
				  	<div class="col-md-11 col-sm-11 col-lg-11 col-xs-10">
				  			<span class="page-headers">Sohan Dhainwal</span>
				  			<span class="msg_time">
				  			  <i class="fa fa-clock-o" aria-hidden="true"></i>
	                           3:49pm 
	                        </span>
				  			<p>Using color to add meaning only provides a visual indication, which will not be conveyed to users of assistive technologies – such as screen readers. Ensure that information denoted by the color is either obvious from th</p>
				  	</div>
			  	</div>
			</div> 
			<div class="panel panel-inverse margin-b0">
			    <div class="panel-body">
				  	<div class="col-md-1 col-sm-1 col-lg-1 col-xs-2">
				  		<div  class="circle-badge">
	            			<strong>S</strong>
	            			
	          			</div>
				  	</div>
				  	<div class="col-md-11 col-sm-11 col-lg-11 col-xs-10">
				  		<span class="page-headers">Sohan Dhainwal</span>
				  			<span class="msg_time">
				  			  <i class="fa fa-clock-o" aria-hidden="true"></i>
	                           3:49pm 
	                        </span>
				  			<p>Using color to add meaning only provides a visual indication, which will not be conveyed to users of assistive technologies – such as screen readers. Ensure that information denoted by the color is either obvious from th</p>
				  	</div>
			     </div>
			</div> 
        </div>
    </div>
    <div class="col-md-12 col-sm-12 col-lg-12 col-xs-12 text-center">
	    <div class="custom_pagination">
			<ul class="pagination m-t-0 m-b-10">
				<li class="disabled"><a href="javascript:;">Previous</a></li>
				<li class="active"><a href="javascript:;">1</a></li>
				<li><a href="javascript:;">2</a></li>
				<li><a href="javascript:;">3</a></li>
				<li><a href="javascript:;">4</a></li>
				<li><a href="javascript:;">5</a></li>
				<li><a href="javascript:;">Next</a></li>
			</ul>
		</div>
	</div>
</div>
