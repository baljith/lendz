<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-11-13 00:04:25 --> Could not find the language line "error_title"
ERROR - 2017-11-13 00:19:26 --> The upload path does not appear to be valid.
ERROR - 2017-11-13 00:45:30 --> The upload path does not appear to be valid.
ERROR - 2017-11-13 00:45:40 --> The upload path does not appear to be valid.
ERROR - 2017-11-13 00:47:12 --> Could not find the language line "error_title"
ERROR - 2017-11-13 05:37:00 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-11-13 05:37:00', 1, 'sub_BcTf9Ddr1dPRT6', 'cus_BbTX8zb6Xm5O98', '8', 0)
ERROR - 2017-11-13 06:35:07 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-11-13 06:35:07', 1, 'sub_BcTf9Ddr1dPRT6', 'cus_BbTX8zb6Xm5O98', '8', 0)
ERROR - 2017-11-13 07:44:31 --> The upload path does not appear to be valid.
ERROR - 2017-11-13 07:50:01 --> Plan already exists.
ERROR - 2017-11-13 08:01:48 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-11-13 08:01:48', 1, 'sub_BcTf9Ddr1dPRT6', 'cus_BbTX8zb6Xm5O98', '8', 0)
ERROR - 2017-11-13 09:21:58 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-11-13 09:21:58', 1, 'sub_BcTf9Ddr1dPRT6', 'cus_BbTX8zb6Xm5O98', '8', 0)
ERROR - 2017-11-13 10:31:58 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-11-13 10:31:58', 1, 'sub_BcTf9Ddr1dPRT6', 'cus_BbTX8zb6Xm5O98', '8', 0)
ERROR - 2017-11-13 13:45:55 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-11-13 13:45:55', 1, 'sub_BbTsGys2ZBYJbz', 'cus_BbRZ9qgztwNzjO', '8', 0)
ERROR - 2017-11-13 14:40:22 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-11-13 14:40:22', 1, 'sub_BbTsGys2ZBYJbz', 'cus_BbRZ9qgztwNzjO', '8', 0)
ERROR - 2017-11-13 15:54:34 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-11-13 15:54:34', 1, 'sub_BbTsGys2ZBYJbz', 'cus_BbRZ9qgztwNzjO', '8', 0)
ERROR - 2017-11-13 16:52:56 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-11-13 16:52:56', 1, 'sub_BbTsGys2ZBYJbz', 'cus_BbRZ9qgztwNzjO', '8', 0)
ERROR - 2017-11-13 17:28:48 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-11-13 17:28:48', 1, 'sub_BbTsGys2ZBYJbz', 'cus_BbRZ9qgztwNzjO', '8', 0)
