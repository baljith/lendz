<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-11-30 10:40:09 --> Query error: Unknown column 'Confirm_User_Password' in 'field list' - Invalid query: UPDATE `ci_users` SET `User_Email` = 'Sohan@mail.com', `Username` = 'Sohand', `Confirm_User_Password` = '', `User_Phone` = '55555655555', `User_Address` = 'Hdhhdhf', `Modified_Date` = '2017-11-30 10:40:09'
WHERE `User_Id` IS NULL
ERROR - 2017-11-30 13:15:09 --> Query error: Unknown column 'fileName' in 'field list' - Invalid query: UPDATE `ci_users` SET `fileName` = '1512047707951.jpg', `User_Image` = 'profile_pic_dd1512047709.jpg'
WHERE `User_Id` IS NULL
