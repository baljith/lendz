<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-12 13:15:04 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\lendz\dashboard\application\views\admin\product_view.php 100
ERROR - 2017-12-12 13:15:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\lendz\dashboard\application\views\admin\product_view.php 100
