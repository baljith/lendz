<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-06 13:08:45 --> Could not find the language line "error_title"
ERROR - 2017-12-06 13:09:30 --> Could not find the language line "error_title"
