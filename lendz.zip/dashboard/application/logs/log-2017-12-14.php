<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-14 05:09:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-14 05:09:05 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 34372 bytes) D:\xampp\htdocs\lendz\dashboard\system\libraries\Image_lib.php 1471
ERROR - 2017-12-14 05:09:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-14 05:09:09 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 34372 bytes) D:\xampp\htdocs\lendz\dashboard\system\libraries\Image_lib.php 1471
ERROR - 2017-12-14 05:09:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-14 05:09:14 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 34372 bytes) D:\xampp\htdocs\lendz\dashboard\system\libraries\Image_lib.php 1471
ERROR - 2017-12-14 05:09:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-14 05:09:14 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 34372 bytes) D:\xampp\htdocs\lendz\dashboard\system\libraries\Image_lib.php 1471
ERROR - 2017-12-14 05:09:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-14 05:09:15 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 34372 bytes) D:\xampp\htdocs\lendz\dashboard\system\libraries\Image_lib.php 1471
ERROR - 2017-12-14 05:09:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-14 05:09:15 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 34372 bytes) D:\xampp\htdocs\lendz\dashboard\system\libraries\Image_lib.php 1471
ERROR - 2017-12-14 05:09:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-14 05:09:15 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 34372 bytes) D:\xampp\htdocs\lendz\dashboard\system\libraries\Image_lib.php 1471
ERROR - 2017-12-14 05:09:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-14 05:09:15 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 34372 bytes) D:\xampp\htdocs\lendz\dashboard\system\libraries\Image_lib.php 1471
ERROR - 2017-12-14 05:09:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-14 05:09:15 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 34372 bytes) D:\xampp\htdocs\lendz\dashboard\system\libraries\Image_lib.php 1471
ERROR - 2017-12-14 05:09:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-14 05:09:16 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 34372 bytes) D:\xampp\htdocs\lendz\dashboard\system\libraries\Image_lib.php 1471
ERROR - 2017-12-14 05:09:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-14 05:09:16 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 34372 bytes) D:\xampp\htdocs\lendz\dashboard\system\libraries\Image_lib.php 1471
ERROR - 2017-12-14 05:09:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-14 05:09:16 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 34372 bytes) D:\xampp\htdocs\lendz\dashboard\system\libraries\Image_lib.php 1471
ERROR - 2017-12-14 05:26:09 --> Could not find the language line "error_title"
ERROR - 2017-12-14 10:07:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '*) as total, SUM(r.Rat_Amount) as overall
FROM `ci_ratings` `r`
WHERE `Rat_On` =' at line 1 - Invalid query: SELECT COUNT(r.*) as total, SUM(r.Rat_Amount) as overall
FROM `ci_ratings` `r`
WHERE `Rat_On` = '3'
AND `Approved` = 'Approved'
ERROR - 2017-12-14 10:38:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-14 10:38:02 --> Severity: Parsing Error --> syntax error, unexpected '?>' D:\xampp\htdocs\lendz\dashboard\application\views\admin\user_view_info.php 98
ERROR - 2017-12-14 11:42:02 --> Severity: Warning --> Division by zero D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Products.php 262
ERROR - 2017-12-14 11:42:02 --> Severity: Warning --> Division by zero D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Products.php 262
ERROR - 2017-12-14 11:42:02 --> Severity: Warning --> Division by zero D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Products.php 262
ERROR - 2017-12-14 11:42:02 --> Severity: Warning --> Division by zero D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Products.php 262
ERROR - 2017-12-14 11:42:14 --> Severity: Warning --> Division by zero D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Products.php 262
ERROR - 2017-12-14 11:42:14 --> Severity: Warning --> Division by zero D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Products.php 262
ERROR - 2017-12-14 11:42:14 --> Severity: Warning --> Division by zero D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Products.php 262
ERROR - 2017-12-14 11:42:14 --> Severity: Warning --> Division by zero D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Products.php 262
ERROR - 2017-12-14 11:42:14 --> Severity: Warning --> Division by zero D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Products.php 262
ERROR - 2017-12-14 11:43:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-14 11:43:09 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Products.php 267
