<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-11-21 12:11:30 --> Could not find the language line "error_title"
