<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-08 09:40:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-08 09:40:15 --> Severity: Parsing Error --> syntax error, unexpected ';' D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Products.php 209
ERROR - 2017-12-08 09:40:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-08 09:40:36 --> Severity: Parsing Error --> syntax error, unexpected ';' D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Products.php 213
ERROR - 2017-12-08 09:40:50 --> Query error: Column 'Id' in where clause is ambiguous - Invalid query: SELECT `p`.*, `c`.`Image`
FROM `ci_products` `p`
LEFT JOIN `ci_categories` `c` ON `c`.`Id`=`p`.`Category_Id`
WHERE `User_Id` = '86'
AND `Id` != '0'
ORDER BY `Created_Date` DESC
 LIMIT 4
ERROR - 2017-12-08 11:01:55 --> Severity: Warning --> file_get_contents(asdfasdf): failed to open stream: No such file or directory D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Users.php 1254
ERROR - 2017-12-08 13:13:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` = '86'
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-12-08 13:13:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` = '86'
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
