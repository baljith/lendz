<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-02 09:19:11 --> Query error: Unknown column 'id' in 'field list' - Invalid query: UPDATE `ci_users` SET `id` = '85', `Verified` = '1'
WHERE `User_Id` = '85'
ERROR - 2017-12-02 09:48:54 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\lendz\dashboard\application\views\admin\product_view.php 54
ERROR - 2017-12-02 10:17:36 --> Query error: Unknown column 'Thread_Type' in 'field list' - Invalid query: INSERT INTO `ci_messages` (`Sent_By`, `Sent_To`, `Message`, `Thread`, `Thread_Type`, `Time_Stamp`, `Date`, `Last`) VALUES ('75', '85', 'dasdsd', 1, 'custom', 1512209856, '2017-12-02 10:17:36', '1')
ERROR - 2017-12-02 10:17:40 --> Query error: Unknown column 'Thread_Type' in 'field list' - Invalid query: INSERT INTO `ci_messages` (`Sent_By`, `Sent_To`, `Message`, `Thread`, `Thread_Type`, `Time_Stamp`, `Date`, `Last`) VALUES ('75', '85', 'dasdsd', 2, 'custom', 1512209860, '2017-12-02 10:17:40', '1')
ERROR - 2017-12-02 10:22:05 --> Query error: Unknown column 'Thread_Type' in 'field list' - Invalid query: INSERT INTO `ci_messages` (`Sent_By`, `Sent_To`, `Message`, `Thread`, `Thread_Type`, `Time_Stamp`, `Date`, `Last`) VALUES ('75', '85', 'dasdasd', 3, 'custom', 1512210125, '2017-12-02 10:22:05', '1')
ERROR - 2017-12-02 10:24:41 --> Query error: Unknown column 'Thread_Type' in 'field list' - Invalid query: INSERT INTO `ci_messages` (`Sent_By`, `Sent_To`, `Message`, `Thread`, `Thread_Type`, `Time_Stamp`, `Date`, `Last`) VALUES ('75', '85', 'sadasdasd', 4, 'custom', 1512210281, '2017-12-02 10:24:41', '1')
ERROR - 2017-12-02 10:26:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` = '85'
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-12-02 10:55:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` = '86'
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
