
ERROR - 2017-10-21 07:56:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 07:56:43 --> Severity: Parsing Error --> syntax error, unexpected '"p.Package_Name"' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\truckapp\dashboard\application\models\datatables\Transaction_list.php 7
ERROR - 2017-10-21 07:57:04 --> Severity: Warning --> Missing argument 1 for Transaction_list::make_datatables(), called in D:\xampp\htdocs\truckapp\dashboard\application\controllers\Transactions.php on line 31 and defined D:\xampp\htdocs\truckapp\dashboard\application\models\datatables\Transaction_list.php 48
ERROR - 2017-10-21 07:57:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'As User_Full_Name LIKE '%%' OR `p`.`Package_Name` LIKE '%%' OR `sb`.`Status` LIK' at line 5 - Invalid query: SELECT CONCAT(u.User_First_Name,' ',u.User_Last_Name) As User_Full_Name, `p`.`Package_Name`, `sb`.`Status`, `sb`.`End_At`
FROM `ci_subscriptions` `sb`
LEFT JOIN `ci_packages` `p` ON `p`.`Package_Id`=`sb`.`Plan_Id`
INNER JOIN `ci_users` `u` ON `u`.`User_Id`=`sb`.`User_Id`
WHERE ( CONCAT(u.User_First_Name,' ',u.User_Last_Name) As User_Full_Name LIKE '%%' OR `p`.`Package_Name` LIKE '%%' OR `sb`.`Status` LIKE '%%' OR `sb`.`End_At` LIKE '%%'  )
AND  IS NULL
ORDER BY CONCAT(u.User_First_Name ASC, ' ' ASC, u.User_Last_Name) As User_Full_Name ASC
 LIMIT 10
ERROR - 2017-10-21 07:57:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'As User_Full_Name LIKE '%%' OR `p`.`Package_Name` LIKE '%%' OR `sb`.`Status` LIK' at line 5 - Invalid query: SELECT CONCAT(u.User_First_Name,' ',u.User_Last_Name) As User_Full_Name, `p`.`Package_Name`, `sb`.`Status`, `sb`.`End_At`
FROM `ci_subscriptions` `sb`
LEFT JOIN `ci_packages` `p` ON `p`.`Package_Id`=`sb`.`Plan_Id`
INNER JOIN `ci_users` `u` ON `u`.`User_Id`=`sb`.`User_Id`
WHERE ( CONCAT(u.User_First_Name,' ',u.User_Last_Name) As User_Full_Name LIKE '%%' OR `p`.`Package_Name` LIKE '%%' OR `sb`.`Status` LIKE '%%' OR `sb`.`End_At` LIKE '%%'  )
ORDER BY `sb`.`Status` ASC
 LIMIT 10
ERROR - 2017-10-21 07:58:14 --> Query error: Unknown column 'User_Full_Name' in 'where clause' - Invalid query: SELECT CONCAT(u.User_First_Name,' ',u.User_Last_Name) As User_Full_Name, `p`.`Package_Name`, `sb`.`Status`, `sb`.`End_At`
FROM `ci_subscriptions` `sb`
LEFT JOIN `ci_packages` `p` ON `p`.`Package_Id`=`sb`.`Plan_Id`
INNER JOIN `ci_users` `u` ON `u`.`User_Id`=`sb`.`User_Id`
WHERE ( User_Full_Name LIKE '%%' OR `p`.`Package_Name` LIKE '%%' OR `sb`.`Status` LIKE '%%' OR `sb`.`End_At` LIKE '%%'  )
ORDER BY `User_Full_Name` ASC
 LIMIT 10
ERROR - 2017-10-21 07:58:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'DESC, ' ' DESC, u.User_Last_Name) DESC
 LIMIT 10' at line 6 - Invalid query: SELECT CONCAT(u.User_First_Name,' ',u.User_Last_Name) As User_Full_Name, `p`.`Package_Name`, `sb`.`Status`, `sb`.`End_At`
FROM `ci_subscriptions` `sb`
LEFT JOIN `ci_packages` `p` ON `p`.`Package_Id`=`sb`.`Plan_Id`
INNER JOIN `ci_users` `u` ON `u`.`User_Id`=`sb`.`User_Id`
WHERE ( CONCAT(u.User_First_Name,' ',u.User_Last_Name) LIKE '%%' OR `p`.`Package_Name` LIKE '%%' OR `sb`.`Status` LIKE '%%' OR `sb`.`End_At` LIKE '%%'  )
ORDER BY CONCAT(u.User_First_Name DESC, ' ' DESC, u.User_Last_Name) DESC
 LIMIT 10
ERROR - 2017-10-21 08:01:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 08:01:30 --> Severity: Parsing Error --> syntax error, unexpected '"p.Package_Name"' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\truckapp\dashboard\application\models\datatables\Transaction_list.php 21
ERROR - 2017-10-21 08:01:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 08:01:33 --> Severity: Parsing Error --> syntax error, unexpected '"p.Package_Name"' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\truckapp\dashboard\application\models\datatables\Transaction_list.php 21
ERROR - 2017-10-21 08:01:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'As User_Full_Name LIKE '%%' OR `p`.`Package_Name` LIKE '%%'  )
ORDER BY `p`.`Pac' at line 5 - Invalid query: SELECT CONCAT(u.User_First_Name,' ',u.User_Last_Name) As User_Full_Name, `p`.`Package_Name`, `sb`.`Status`, `sb`.`End_At`
FROM `ci_subscriptions` `sb`
LEFT JOIN `ci_packages` `p` ON `p`.`Package_Id`=`sb`.`Plan_Id`
INNER JOIN `ci_users` `u` ON `u`.`User_Id`=`sb`.`User_Id`
WHERE ( CONCAT(u.User_First_Name,' ',u.User_Last_Name) As User_Full_Name LIKE '%%' OR `p`.`Package_Name` LIKE '%%'  )
ORDER BY `p`.`Package_Name` ASC
 LIMIT 10
ERROR - 2017-10-21 08:01:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'As User_Full_Name LIKE '%%' OR `p`.`Package_Name` LIKE '%%'  )
ORDER BY `User_Fu' at line 5 - Invalid query: SELECT CONCAT(u.User_First_Name,' ',u.User_Last_Name) As User_Full_Name, `p`.`Package_Name`, `sb`.`Status`, `sb`.`End_At`
FROM `ci_subscriptions` `sb`
LEFT JOIN `ci_packages` `p` ON `p`.`Package_Id`=`sb`.`Plan_Id`
INNER JOIN `ci_users` `u` ON `u`.`User_Id`=`sb`.`User_Id`
WHERE ( CONCAT(u.User_First_Name,' ',u.User_Last_Name) As User_Full_Name LIKE '%%' OR `p`.`Package_Name` LIKE '%%'  )
ORDER BY `User_Full_Name` ASC
 LIMIT 10
ERROR - 2017-10-21 08:59:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'DESC, ' ' DESC, u.User_Last_Name) As User_Full_Name DESC
 LIMIT 10' at line 6 - Invalid query: SELECT CONCAT(u.User_First_Name,' ',u.User_Last_Name) As User_Full_Name, `p`.`Package_Name`, `sb`.`Status`, `sb`.`End_At`
FROM `ci_subscriptions` `sb`
LEFT JOIN `ci_packages` `p` ON `p`.`Package_Id`=`sb`.`Plan_Id`
INNER JOIN `ci_users` `u` ON `u`.`User_Id`=`sb`.`User_Id`
WHERE ( CONCAT(u.User_First_Name,' ',u.User_Last_Name) LIKE '%%' OR `p`.`Package_Name` LIKE '%%'  )
ORDER BY CONCAT(u.User_First_Name DESC, ' ' DESC, u.User_Last_Name) As User_Full_Name DESC
 LIMIT 10
ERROR - 2017-10-21 08:59:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'DESC, ' ' DESC, u.User_Last_Name) As User_Full_Name DESC
 LIMIT 10' at line 6 - Invalid query: SELECT CONCAT(u.User_First_Name,' ',u.User_Last_Name) As User_Full_Name, `p`.`Package_Name`, `sb`.`Status`, `sb`.`End_At`
FROM `ci_subscriptions` `sb`
LEFT JOIN `ci_packages` `p` ON `p`.`Package_Id`=`sb`.`Plan_Id`
INNER JOIN `ci_users` `u` ON `u`.`User_Id`=`sb`.`User_Id`
WHERE ( CONCAT(u.User_First_Name,' ',u.User_Last_Name) LIKE '%%' OR `p`.`Package_Name` LIKE '%%'  )
ORDER BY CONCAT(u.User_First_Name DESC, ' ' DESC, u.User_Last_Name) As User_Full_Name DESC
 LIMIT 10
ERROR - 2017-10-21 09:01:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:01:04 --> Severity: Parsing Error --> syntax error, unexpected '"CONCAT(u.User_First_Name,' ',' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\truckapp\dashboard\application\models\datatables\Transaction_list.php 7
ERROR - 2017-10-21 09:40:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:40:10 --> Severity: Parsing Error --> syntax error, unexpected '"sb.Subs_Id"' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\truckapp\dashboard\application\models\datatables\Transaction_list.php 12
ERROR - 2017-10-21 09:40:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:40:36 --> Severity: Parsing Error --> syntax error, unexpected '"sb.Subs_Id"' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\truckapp\dashboard\application\models\datatables\Transaction_list.php 12
ERROR - 2017-10-21 09:40:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:40:43 --> Severity: Parsing Error --> syntax error, unexpected '"sb.Subs_Id"' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\truckapp\dashboard\application\models\datatables\Transaction_list.php 12
ERROR - 2017-10-21 09:46:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:46:58 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ';' or '{' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 533
ERROR - 2017-10-21 09:46:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:46:58 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ';' or '{' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 533
ERROR - 2017-10-21 09:47:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:47:01 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ';' or '{' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 533
ERROR - 2017-10-21 09:47:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:47:01 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ';' or '{' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 533
ERROR - 2017-10-21 09:47:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:47:34 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 537
ERROR - 2017-10-21 09:47:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:47:34 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 537
ERROR - 2017-10-21 09:47:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:47:37 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 537
ERROR - 2017-10-21 09:47:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:47:37 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 537
ERROR - 2017-10-21 09:47:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:47:40 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 537
ERROR - 2017-10-21 09:47:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:47:40 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 537
ERROR - 2017-10-21 09:47:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:47:43 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 537
ERROR - 2017-10-21 09:47:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:47:43 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 537
ERROR - 2017-10-21 09:47:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:47:46 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 537
ERROR - 2017-10-21 09:47:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:47:46 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 537
ERROR - 2017-10-21 09:47:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:47:49 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 537
ERROR - 2017-10-21 09:47:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:47:49 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 537
ERROR - 2017-10-21 09:47:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:47:52 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 537
ERROR - 2017-10-21 09:47:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:47:52 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 537
ERROR - 2017-10-21 09:47:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:47:55 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 537
ERROR - 2017-10-21 09:47:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:47:55 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 537
ERROR - 2017-10-21 09:47:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:47:58 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 537
ERROR - 2017-10-21 09:47:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:47:58 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 537
ERROR - 2017-10-21 09:48:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:48:01 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 537
ERROR - 2017-10-21 09:48:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:48:01 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 537
ERROR - 2017-10-21 09:48:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:48:04 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 537
ERROR - 2017-10-21 09:48:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:48:04 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 537
ERROR - 2017-10-21 09:48:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:48:07 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 537
ERROR - 2017-10-21 09:48:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:48:07 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 537
ERROR - 2017-10-21 09:48:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:48:10 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 537
ERROR - 2017-10-21 09:48:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:48:10 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 537
ERROR - 2017-10-21 09:48:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:48:13 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 537
ERROR - 2017-10-21 09:48:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:48:13 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 537
ERROR - 2017-10-21 09:48:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:48:16 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 537
ERROR - 2017-10-21 09:48:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:48:16 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 537
ERROR - 2017-10-21 09:49:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:49:01 --> Severity: Parsing Error --> syntax error, unexpected '\' (T_NS_SEPARATOR) D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 536
ERROR - 2017-10-21 09:49:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:49:01 --> Severity: Parsing Error --> syntax error, unexpected '\' (T_NS_SEPARATOR) D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 536
ERROR - 2017-10-21 09:49:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:49:04 --> Severity: Parsing Error --> syntax error, unexpected '\' (T_NS_SEPARATOR) D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 536
ERROR - 2017-10-21 09:49:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:49:05 --> Severity: Parsing Error --> syntax error, unexpected '\' (T_NS_SEPARATOR) D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 536
ERROR - 2017-10-21 09:49:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:49:07 --> Severity: Parsing Error --> syntax error, unexpected '\' (T_NS_SEPARATOR) D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 536
ERROR - 2017-10-21 09:49:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:49:07 --> Severity: Parsing Error --> syntax error, unexpected '\' (T_NS_SEPARATOR) D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 536
ERROR - 2017-10-21 09:49:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:49:10 --> Severity: Parsing Error --> syntax error, unexpected '\' (T_NS_SEPARATOR) D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 536
ERROR - 2017-10-21 09:49:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:49:10 --> Severity: Parsing Error --> syntax error, unexpected '\' (T_NS_SEPARATOR) D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 536
ERROR - 2017-10-21 09:49:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:49:13 --> Severity: Parsing Error --> syntax error, unexpected '\' (T_NS_SEPARATOR) D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 536
ERROR - 2017-10-21 09:49:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:49:13 --> Severity: Parsing Error --> syntax error, unexpected '\' (T_NS_SEPARATOR) D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 536
ERROR - 2017-10-21 09:50:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:50:37 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 551
ERROR - 2017-10-21 09:50:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:50:37 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 551
ERROR - 2017-10-21 09:50:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:50:40 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 551
ERROR - 2017-10-21 09:50:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:50:40 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 551
ERROR - 2017-10-21 09:50:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:50:43 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 551
ERROR - 2017-10-21 09:50:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:50:43 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 551
ERROR - 2017-10-21 09:50:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:50:46 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 551
ERROR - 2017-10-21 09:50:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:50:46 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 551
ERROR - 2017-10-21 09:50:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:50:49 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 551
ERROR - 2017-10-21 09:50:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:50:49 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 551
ERROR - 2017-10-21 09:50:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:50:52 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 551
ERROR - 2017-10-21 09:50:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:50:52 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 551
ERROR - 2017-10-21 09:50:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:50:55 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 551
ERROR - 2017-10-21 09:50:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:50:55 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 551
ERROR - 2017-10-21 09:50:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:50:58 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 551
ERROR - 2017-10-21 09:50:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:50:58 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 551
ERROR - 2017-10-21 09:51:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:01 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 551
ERROR - 2017-10-21 09:51:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:01 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 551
ERROR - 2017-10-21 09:51:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:04 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 551
ERROR - 2017-10-21 09:51:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:04 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 551
ERROR - 2017-10-21 09:51:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:07 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 552
ERROR - 2017-10-21 09:51:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:07 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 552
ERROR - 2017-10-21 09:51:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:10 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 552
ERROR - 2017-10-21 09:51:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:10 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 552
ERROR - 2017-10-21 09:51:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:13 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 552
ERROR - 2017-10-21 09:51:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:13 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 552
ERROR - 2017-10-21 09:51:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:16 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 552
ERROR - 2017-10-21 09:51:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:16 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 552
ERROR - 2017-10-21 09:51:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:19 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 552
ERROR - 2017-10-21 09:51:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:19 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 552
ERROR - 2017-10-21 09:51:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:22 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 552
ERROR - 2017-10-21 09:51:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:22 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 552
ERROR - 2017-10-21 09:51:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:25 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 552
ERROR - 2017-10-21 09:51:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:25 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 552
ERROR - 2017-10-21 09:51:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:28 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 552
ERROR - 2017-10-21 09:51:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:28 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 552
ERROR - 2017-10-21 09:51:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:31 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 552
ERROR - 2017-10-21 09:51:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:31 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 552
ERROR - 2017-10-21 09:51:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:34 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 552
ERROR - 2017-10-21 09:51:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:34 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 552
ERROR - 2017-10-21 09:51:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:37 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 552
ERROR - 2017-10-21 09:51:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:37 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 552
ERROR - 2017-10-21 09:51:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:40 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 552
ERROR - 2017-10-21 09:51:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:40 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 552
ERROR - 2017-10-21 09:51:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:43 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 552
ERROR - 2017-10-21 09:51:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:43 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 552
ERROR - 2017-10-21 09:51:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:46 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 552
ERROR - 2017-10-21 09:51:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:47 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 552
ERROR - 2017-10-21 09:51:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:49 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 552
ERROR - 2017-10-21 09:51:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:49 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 552
ERROR - 2017-10-21 09:51:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:52 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 552
ERROR - 2017-10-21 09:51:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:52 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 552
ERROR - 2017-10-21 09:51:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:55 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 552
ERROR - 2017-10-21 09:51:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:55 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 552
ERROR - 2017-10-21 09:51:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:58 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 553
ERROR - 2017-10-21 09:51:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:51:58 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 553
ERROR - 2017-10-21 09:52:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:52:01 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 553
ERROR - 2017-10-21 09:52:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:52:01 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 553
ERROR - 2017-10-21 09:52:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:52:04 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 553
ERROR - 2017-10-21 09:52:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:52:04 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 553
ERROR - 2017-10-21 09:52:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:52:07 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 553
ERROR - 2017-10-21 09:52:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:52:07 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 553
ERROR - 2017-10-21 09:52:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:52:10 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 554
ERROR - 2017-10-21 09:52:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:52:10 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 554
ERROR - 2017-10-21 09:52:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:52:13 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 554
ERROR - 2017-10-21 09:52:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:52:13 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 554
ERROR - 2017-10-21 09:52:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:52:16 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 554
ERROR - 2017-10-21 09:52:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:52:16 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 554
ERROR - 2017-10-21 09:52:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:52:19 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 554
ERROR - 2017-10-21 09:52:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:52:19 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 554
ERROR - 2017-10-21 09:52:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:52:22 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 554
ERROR - 2017-10-21 09:52:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:52:22 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 554
ERROR - 2017-10-21 09:52:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:52:25 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 554
ERROR - 2017-10-21 09:52:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:52:25 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 554
ERROR - 2017-10-21 09:52:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:52:28 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 554
ERROR - 2017-10-21 09:52:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:52:28 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 554
ERROR - 2017-10-21 09:52:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:52:31 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 554
ERROR - 2017-10-21 09:52:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:52:31 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 554
ERROR - 2017-10-21 09:52:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:52:34 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 554
ERROR - 2017-10-21 09:52:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:52:34 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 554
ERROR - 2017-10-21 09:52:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:52:37 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 554
ERROR - 2017-10-21 09:52:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:52:37 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 554
ERROR - 2017-10-21 09:52:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:52:40 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 554
ERROR - 2017-10-21 09:52:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:52:40 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 554
ERROR - 2017-10-21 09:52:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:52:43 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 554
ERROR - 2017-10-21 09:52:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:52:43 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 554
ERROR - 2017-10-21 09:52:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:52:46 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 554
ERROR - 2017-10-21 09:52:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:52:46 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 554
ERROR - 2017-10-21 09:52:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:52:49 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 554
ERROR - 2017-10-21 09:52:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:52:49 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 554
ERROR - 2017-10-21 09:53:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 09:53:46 --> Severity: Error --> Cannot use object of type stdClass as array D:\xampp\htdocs\truckapp\dashboard\application\models\Common_model.php 550
ERROR - 2017-10-21 10:16:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 10:16:02 --> Severity: Parsing Error --> syntax error, unexpected ''transactions'' (T_CONSTANT_ENCAPSED_STRING) D:\xampp\htdocs\truckapp\dashboard\application\views\admin\transaction_view.php 105
ERROR - 2017-10-21 10:43:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 10:43:46 --> Severity: Parsing Error --> syntax error, unexpected '' for Membership "'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\truckapp\dashboard\application\controllers\Register.php 286
ERROR - 2017-10-21 10:43:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 10:43:50 --> Severity: Parsing Error --> syntax error, unexpected '' for Membership "'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\truckapp\dashboard\application\controllers\Register.php 286
ERROR - 2017-10-21 10:43:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 10:43:53 --> Severity: Parsing Error --> syntax error, unexpected '' for Membership "'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\truckapp\dashboard\application\controllers\Register.php 286
ERROR - 2017-10-21 10:43:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 10:43:55 --> Severity: Parsing Error --> syntax error, unexpected '' for Membership "'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\truckapp\dashboard\application\controllers\Register.php 286
ERROR - 2017-10-21 10:49:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 10:49:27 --> Severity: Parsing Error --> syntax error, unexpected ''Subs_Id'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\truckapp\dashboard\application\controllers\Transactions.php 116
ERROR - 2017-10-21 10:49:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 10:49:27 --> Severity: Parsing Error --> syntax error, unexpected ''Subs_Id'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\truckapp\dashboard\application\controllers\Transactions.php 116
ERROR - 2017-10-21 10:49:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 10:49:28 --> Severity: Parsing Error --> syntax error, unexpected ''Subs_Id'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\truckapp\dashboard\application\controllers\Transactions.php 116
ERROR - 2017-10-21 10:49:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 10:49:28 --> Severity: Parsing Error --> syntax error, unexpected ''Subs_Id'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\truckapp\dashboard\application\controllers\Transactions.php 116
ERROR - 2017-10-21 10:49:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 10:49:28 --> Severity: Parsing Error --> syntax error, unexpected ''Subs_Id'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\truckapp\dashboard\application\controllers\Transactions.php 116
ERROR - 2017-10-21 10:49:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 10:49:28 --> Severity: Parsing Error --> syntax error, unexpected ''Subs_Id'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\truckapp\dashboard\application\controllers\Transactions.php 116
ERROR - 2017-10-21 10:55:08 --> No such subscription: sub_BcVTFiBNIv4lPM
ERROR - 2017-10-21 10:55:39 --> No such subscription: sub_BcVTFiBNIv4lPM
ERROR - 2017-10-21 10:57:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 10:57:03 --> Severity: Parsing Error --> syntax error, unexpected '' for Membership "'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\truckapp\dashboard\application\controllers\Register.php 286
ERROR - 2017-10-21 10:57:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 10:57:04 --> Severity: Parsing Error --> syntax error, unexpected '' for Membership "'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\truckapp\dashboard\application\controllers\Register.php 286
ERROR - 2017-10-21 10:57:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 10:57:27 --> Severity: Parsing Error --> syntax error, unexpected '' for Membership "'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\truckapp\dashboard\application\controllers\Register.php 286
ERROR - 2017-10-21 10:57:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\truckapp\wp-includes\functions.php:3721) D:\xampp\htdocs\truckapp\dashboard\system\core\Common.php 570
ERROR - 2017-10-21 10:57:52 --> Severity: Parsing Error --> syntax error, unexpected '' for Membership '' (T_CONSTANT_ENCAPSED_STRING), expecting ')' D:\xampp\htdocs\truckapp\dashboard\application\controllers\Register.php 286
ERROR - 2017-10-21 12:21:00 --> Query error: Illegal mix of collations (latin1_swedish_ci,IMPLICIT) and (utf8_general_ci,COERCIBLE) for operation '=' - Invalid query: SELECT *
FROM `ci_users`
WHERE `User_Email` = '�w^~)�'
