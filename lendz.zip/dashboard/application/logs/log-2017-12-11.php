<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-11 06:13:57 --> Query error: Unknown column 'Rent' in 'order clause' - Invalid query: SELECT p.*,c.Name,
            ( 3959 * acos ( cos ( radians("30.905865") ) * cos( radians( `p`.`Latitude` ) ) * cos( radians( `p`.`Longitude` ) - radians("75.836304") ) + sin ( radians("30.905865") ) * sin( radians( `p`.`Latitude` ) ) ) ) AS distance
            FROM ci_products p LEFT JOIN ci_categories c ON c.Id=p.Category_Id 
            WHERE Booking_Status="Available"   AND User_Id!="86" AND p.Booking_Status="Available" AND p.Status="Approved" ORDER BY Rent asc LIMIT 10
ERROR - 2017-12-11 06:25:45 --> Query error: Column 'Created_Date' in where clause is ambiguous - Invalid query: SELECT p.*,c.Name,
            ( 3959 * acos ( cos ( radians("30.905865") ) * cos( radians( `p`.`Latitude` ) ) * cos( radians( `p`.`Longitude` ) - radians("75.836304") ) + sin ( radians("30.905865") ) * sin( radians( `p`.`Latitude` ) ) ) ) AS distance
            FROM ci_products p LEFT JOIN ci_categories c ON c.Id=p.Category_Id 
            WHERE Booking_Status="Available"   AND User_Id!="86" AND p.Booking_Status="Available" AND p.Status="Approved"  AND CAST(`Created_Date` AS DATE)<="2017-12-10" ORDER BY Created_Date desc LIMIT 10
ERROR - 2017-12-11 07:25:28 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (ci_sessions) Unknown 0
ERROR - 2017-12-11 07:25:28 --> Query error: Server shutdown in progress - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1512977128
WHERE `id` = 'k1sfng9hndvfncjfl3gfdfopt3komn76'
ERROR - 2017-12-11 07:25:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-11 07:25:28 --> Severity: Warning --> mysqli::query(): MySQL server has gone away D:\xampp\htdocs\lendz\dashboard\system\database\drivers\mysqli\mysqli_driver.php 305
ERROR - 2017-12-11 07:25:28 --> Severity: Warning --> mysqli::query(): Error reading result set's header D:\xampp\htdocs\lendz\dashboard\system\database\drivers\mysqli\mysqli_driver.php 305
ERROR - 2017-12-11 07:25:28 --> Query error: MySQL server has gone away - Invalid query: SELECT RELEASE_LOCK('99ad13ad914d784b0bb15c3b1f8c6491') AS ci_session_lock
ERROR - 2017-12-11 07:25:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-11 10:47:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-11 10:47:08 --> Severity: Parsing Error --> syntax error, unexpected '$notification' (T_VARIABLE) D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Chat.php 85
ERROR - 2017-12-11 10:47:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-11 10:47:09 --> Severity: Parsing Error --> syntax error, unexpected '$notification' (T_VARIABLE) D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Chat.php 85
ERROR - 2017-12-11 10:47:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-11 10:47:15 --> Severity: Parsing Error --> syntax error, unexpected '$notification' (T_VARIABLE) D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Chat.php 85
ERROR - 2017-12-11 10:47:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-11 10:47:19 --> Severity: Parsing Error --> syntax error, unexpected '$notification' (T_VARIABLE) D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Chat.php 85
ERROR - 2017-12-11 10:47:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-11 10:47:22 --> Severity: Parsing Error --> syntax error, unexpected '$notification' (T_VARIABLE) D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Chat.php 85
ERROR - 2017-12-11 10:47:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-11 10:47:22 --> Severity: Parsing Error --> syntax error, unexpected '$notification' (T_VARIABLE) D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Chat.php 85
ERROR - 2017-12-11 10:47:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-11 10:47:27 --> Severity: Parsing Error --> syntax error, unexpected '$notification' (T_VARIABLE) D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Chat.php 85
ERROR - 2017-12-11 10:47:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-11 10:47:30 --> Severity: Parsing Error --> syntax error, unexpected '$notification' (T_VARIABLE) D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Chat.php 85
ERROR - 2017-12-11 10:54:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-11 10:54:47 --> Severity: Parsing Error --> syntax error, unexpected '$notification' (T_VARIABLE) D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Chat.php 85
ERROR - 2017-12-11 10:54:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-11 10:54:49 --> Severity: Parsing Error --> syntax error, unexpected '$notification' (T_VARIABLE) D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Chat.php 85
ERROR - 2017-12-11 10:54:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-11 10:54:52 --> Severity: Parsing Error --> syntax error, unexpected '$notification' (T_VARIABLE) D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Chat.php 85
ERROR - 2017-12-11 10:54:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-11 10:54:54 --> Severity: Parsing Error --> syntax error, unexpected '$notification' (T_VARIABLE) D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Chat.php 85
ERROR - 2017-12-11 10:54:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-11 10:54:56 --> Severity: Parsing Error --> syntax error, unexpected '$notification' (T_VARIABLE) D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Chat.php 85
ERROR - 2017-12-11 10:54:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-11 10:54:58 --> Severity: Parsing Error --> syntax error, unexpected '$notification' (T_VARIABLE) D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Chat.php 85
ERROR - 2017-12-11 10:55:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-11 10:55:01 --> Severity: Parsing Error --> syntax error, unexpected '$notification' (T_VARIABLE) D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Chat.php 85
ERROR - 2017-12-11 10:55:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-11 10:55:03 --> Severity: Parsing Error --> syntax error, unexpected '$notification' (T_VARIABLE) D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Chat.php 85
ERROR - 2017-12-11 10:55:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-11 10:55:05 --> Severity: Parsing Error --> syntax error, unexpected '$notification' (T_VARIABLE) D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Chat.php 85
ERROR - 2017-12-11 10:55:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-11 10:55:07 --> Severity: Parsing Error --> syntax error, unexpected '$notification' (T_VARIABLE) D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Chat.php 85
ERROR - 2017-12-11 10:55:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-11 10:55:10 --> Severity: Parsing Error --> syntax error, unexpected '$notification' (T_VARIABLE) D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Chat.php 85
ERROR - 2017-12-11 10:55:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-11 10:55:10 --> Severity: Parsing Error --> syntax error, unexpected '$notification' (T_VARIABLE) D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Chat.php 85
ERROR - 2017-12-11 10:55:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3722) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-12-11 10:55:13 --> Severity: Parsing Error --> syntax error, unexpected '$notification' (T_VARIABLE) D:\xampp\htdocs\lendz\dashboard\application\controllers\api\Chat.php 85
