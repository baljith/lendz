<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-11-06 05:38:47 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-11-06 05:38:47', 1, 'sub_BcTf9Ddr1dPRT6', 'cus_BbTX8zb6Xm5O98', '8', 0)
ERROR - 2017-11-06 06:33:13 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-11-06 06:33:13', 1, 'sub_BcTf9Ddr1dPRT6', 'cus_BbTX8zb6Xm5O98', '8', 0)
ERROR - 2017-11-06 07:20:28 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-11-06 07:20:28', 1, 'sub_BcTf9Ddr1dPRT6', 'cus_BbTX8zb6Xm5O98', '8', 0)
ERROR - 2017-11-06 08:22:39 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-11-06 08:22:39', 1, 'sub_BcTf9Ddr1dPRT6', 'cus_BbTX8zb6Xm5O98', '8', 0)
ERROR - 2017-11-06 09:23:33 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-11-06 09:23:33', 1, 'sub_BcTf9Ddr1dPRT6', 'cus_BbTX8zb6Xm5O98', '8', 0)
ERROR - 2017-11-06 11:29:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `t`.`Created_Date` DESC
 LIMIT 10' at line 9 - Invalid query: SELECT `t`.*, `u`.`User_First_Name`, `u`.`User_Last_Name`, `u`.`Username`, `u`.`User_Email`, `u`.`User_Franchise_Name`, `u`.`User_Buisness_Address`
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` = '100'
AND `t`.`Is_Deleted` = '0'
AND `t`.`Type` = 'needed'
AND `t`.`Description` LIKE '%p%' || CONCAT(u.User_First_Name,' ',u.User_Last_Name LIKE '%p%'
ORDER BY `t`.`Created_Date` DESC
 LIMIT 10
ERROR - 2017-11-06 11:29:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `t`.`Created_Date` DESC
 LIMIT 10' at line 9 - Invalid query: SELECT `t`.*, `u`.`User_First_Name`, `u`.`User_Last_Name`, `u`.`Username`, `u`.`User_Email`, `u`.`User_Franchise_Name`, `u`.`User_Buisness_Address`
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` = '100'
AND `t`.`Is_Deleted` = '0'
AND `t`.`Type` = 'needed'
AND `t`.`Description` LIKE '%p%' || CONCAT(u.User_First_Name,' ',u.User_Last_Name LIKE '%p%'
ORDER BY `t`.`Created_Date` DESC
 LIMIT 10
ERROR - 2017-11-06 11:29:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `t`.`Created_Date` DESC
 LIMIT 10' at line 9 - Invalid query: SELECT `t`.*, `u`.`User_First_Name`, `u`.`User_Last_Name`, `u`.`Username`, `u`.`User_Email`, `u`.`User_Franchise_Name`, `u`.`User_Buisness_Address`
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` = '100'
AND `t`.`Is_Deleted` = '0'
AND `t`.`Type` = 'needed'
AND `t`.`Description` LIKE '%pa%' || CONCAT(u.User_First_Name,' ',u.User_Last_Name LIKE '%pa%'
ORDER BY `t`.`Created_Date` DESC
 LIMIT 10
ERROR - 2017-11-06 13:08:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.User_Last_Name, " )" ) as Full_Name, `u`.`User_First_Name`, `u`.`User_Last_Name' at line 1 - Invalid query: SELECT `t`.*, CONCAT(t.Description, "(", `u`.`User_First_Name`, " "u.User_Last_Name, " )" ) as Full_Name, `u`.`User_First_Name`, `u`.`User_Last_Name`, `u`.`Username`, `u`.`User_Email`, `u`.`User_Franchise_Name`, `u`.`User_Buisness_Address`
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` = '100'
AND `t`.`Is_Deleted` = '0'
AND `t`.`Type` = 'needed'
ORDER BY `t`.`Created_Date` DESC
 LIMIT 10
ERROR - 2017-11-06 13:09:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.User_Last_Name, " )" ) as Full_Name, `u`.`User_First_Name`, `u`.`User_Last_Name' at line 1 - Invalid query: SELECT `t`.*, CONCAT(t.Description, "(", `u`.`User_First_Name`, " "u.User_Last_Name, " )" ) as Full_Name, `u`.`User_First_Name`, `u`.`User_Last_Name`, `u`.`Username`, `u`.`User_Email`, `u`.`User_Franchise_Name`, `u`.`User_Buisness_Address`
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` = '100'
AND `t`.`Is_Deleted` = '0'
AND `t`.`Type` = 'needed'
ORDER BY `t`.`Created_Date` DESC
 LIMIT 10
ERROR - 2017-11-06 13:09:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.User_Last_Name, " )" ) as Full_Name, `u`.`User_First_Name`, `u`.`User_Last_Name' at line 1 - Invalid query: SELECT `t`.*, CONCAT(t.Description, "(", `u`.`User_First_Name`, " "u.User_Last_Name, " )" ) as Full_Name, `u`.`User_First_Name`, `u`.`User_Last_Name`, `u`.`Username`, `u`.`User_Email`, `u`.`User_Franchise_Name`, `u`.`User_Buisness_Address`
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` = '100'
AND `t`.`Is_Deleted` = '0'
AND `t`.`Type` = 'needed'
AND `t`.`Description` LIKE '%s%' || CONCAT(u.User_First_Name,'',u.User_Last_Name) LIKE '%s%'
ORDER BY `t`.`Created_Date` DESC
 LIMIT 10
ERROR - 2017-11-06 13:20:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-11-06 13:45:22 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-11-06 13:45:22', 1, 'sub_BbTsGys2ZBYJbz', 'cus_BbRZ9qgztwNzjO', '8', 0)
ERROR - 2017-11-06 14:12:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-11-06 14:51:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-11-06 15:14:57 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-11-06 15:14:57', 1, 'sub_BbTsGys2ZBYJbz', 'cus_BbRZ9qgztwNzjO', '8', 0)
ERROR - 2017-11-06 15:33:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-11-06 16:37:56 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-11-06 16:37:55', 1, 'sub_BbTsGys2ZBYJbz', 'cus_BbRZ9qgztwNzjO', '8', 0)
ERROR - 2017-11-06 16:47:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `Type` = 'needed'' at line 7 - Invalid query: SELECT *
FROM `ci_tools` `t`
LEFT JOIN `ci_users` `u` ON `u`.`User_Id` = `t`.`User_Id`
LEFT JOIN `ci_connected` `c` ON `c`.`From_User`=`t`.`User_Id`
WHERE `c`.`To_User` IS NULL
AND `t`.`Is_Deleted` = '0'
AND `t`.`Created_Date` > `IS` `NULL`
AND `Type` = 'needed'
ERROR - 2017-11-06 17:12:35 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-11-06 17:12:35', 1, 'sub_BbTsGys2ZBYJbz', 'cus_BbRZ9qgztwNzjO', '8', 0)
