<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-11-02 05:37:12 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-11-02 05:37:12', 1, 'sub_BcTf9Ddr1dPRT6', 'cus_BbTX8zb6Xm5O98', '8', 0)
ERROR - 2017-11-02 06:37:12 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-11-02 06:37:12', 1, 'sub_BcTf9Ddr1dPRT6', 'cus_BbTX8zb6Xm5O98', '8', 0)
ERROR - 2017-11-02 07:59:48 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-11-02 07:59:48', 1, 'sub_BcTf9Ddr1dPRT6', 'cus_BbTX8zb6Xm5O98', '8', 0)
ERROR - 2017-11-02 09:11:14 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-11-02 09:11:14', 1, 'sub_BcTf9Ddr1dPRT6', 'cus_BbTX8zb6Xm5O98', '8', 0)
ERROR - 2017-11-02 09:11:25 --> Could not find the language line "error_title"
ERROR - 2017-11-02 09:11:50 --> Could not find the language line "error_title"
ERROR - 2017-11-02 09:11:54 --> Could not find the language line "error_title"
ERROR - 2017-11-02 09:11:57 --> Could not find the language line "error_title"
ERROR - 2017-11-02 09:12:01 --> Could not find the language line "error_title"
ERROR - 2017-11-02 09:12:42 --> Could not find the language line "error_title"
ERROR - 2017-11-02 09:12:42 --> Could not find the language line "error_title"
ERROR - 2017-11-02 09:12:48 --> Could not find the language line "error_title"
ERROR - 2017-11-02 10:23:33 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-11-02 10:23:33', 1, 'sub_BcTf9Ddr1dPRT6', 'cus_BbTX8zb6Xm5O98', '8', 0)
ERROR - 2017-11-02 11:05:53 --> Could not find the language line "error_title"
ERROR - 2017-11-02 11:55:35 --> Your card was declined.
ERROR - 2017-11-02 11:59:38 --> Your card was declined.
ERROR - 2017-11-02 12:00:19 --> Your card was declined.
ERROR - 2017-11-02 12:00:52 --> An error occurred while processing your card. Try again in a little bit.
ERROR - 2017-11-02 12:01:41 --> Your card has expired.
ERROR - 2017-11-02 12:19:59 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-11-02 12:19:59', 1, 'sub_Bh5rNnqKerOymX', 'cus_BcVSgKqEP4aNZO', 'Demo-daily', 0)
ERROR - 2017-11-02 12:27:14 --> Severity: error --> Exception: No such event: evt_00000000000000 D:\xampp\htdocs\truckapp\dashboard\vendor\stripe\stripe-php\lib\ApiRequestor.php 124
ERROR - 2017-11-02 12:29:39 --> Severity: error --> Exception: No such event: evt_00000000000000 D:\xampp\htdocs\truckapp\dashboard\vendor\stripe\stripe-php\lib\ApiRequestor.php 124
ERROR - 2017-11-02 12:29:56 --> Severity: error --> Exception: No such event: evt_00000000000000 D:\xampp\htdocs\truckapp\dashboard\vendor\stripe\stripe-php\lib\ApiRequestor.php 124
ERROR - 2017-11-02 13:05:34 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-11-02 13:05:34', 1, 'sub_Bh5rNnqKerOymX', 'cus_BcVSgKqEP4aNZO', 'Demo-daily', 0)
ERROR - 2017-11-02 13:45:19 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-11-02 13:45:19', 1, 'sub_BbTsGys2ZBYJbz', 'cus_BbRZ9qgztwNzjO', '8', 0)
ERROR - 2017-11-02 14:20:23 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-11-02 14:20:23', 1, 'sub_Bh5rNnqKerOymX', 'cus_BcVSgKqEP4aNZO', 'Demo-daily', 0)
ERROR - 2017-11-02 14:27:03 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-11-02 14:27:03', 1, 'sub_BbTsGys2ZBYJbz', 'cus_BbRZ9qgztwNzjO', '8', 0)
ERROR - 2017-11-02 14:54:48 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-11-02 14:54:48', 1, 'sub_Bh5rNnqKerOymX', 'cus_BcVSgKqEP4aNZO', 'Demo-daily', 0)
ERROR - 2017-11-02 15:24:11 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-11-02 15:24:11', 1, 'sub_BbTsGys2ZBYJbz', 'cus_BbRZ9qgztwNzjO', '8', 0)
ERROR - 2017-11-02 16:15:58 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-11-02 16:15:58', 1, 'sub_Bh5rNnqKerOymX', 'cus_BcVSgKqEP4aNZO', 'Demo-daily', 0)
ERROR - 2017-11-02 16:42:04 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-11-02 16:42:04', 1, 'sub_BbTsGys2ZBYJbz', 'cus_BbRZ9qgztwNzjO', '8', 0)
ERROR - 2017-11-02 17:41:20 --> Query error: Column 'User_Id' cannot be null - Invalid query: INSERT INTO `ci_transactions` (`User_Id`, `Payment`, `Created_At`, `Status`, `Subs_Id`, `Cust_Id`, `Plan_Id`, `Balance`) VALUES (NULL, 1000, '2017-11-02 17:41:20', 1, 'sub_BbTsGys2ZBYJbz', 'cus_BbRZ9qgztwNzjO', '8', 0)
