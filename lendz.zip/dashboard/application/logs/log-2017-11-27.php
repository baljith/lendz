<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-11-27 06:01:24 --> Query error: Unknown column 'User_First_Name' in 'field list' - Invalid query: UPDATE `ci_users` SET `User_First_Name` = 'Lendz', `User_Last_Name` = 'App', `User_Email` = 'adam@lendzapp.com', `User_Phone` = '3604478406', `Modified_Date` = '2017-11-27 06:01:24'
WHERE `User_Id` = '75'
ERROR - 2017-11-27 06:01:32 --> Query error: Unknown column 'User_First_Name' in 'field list' - Invalid query: UPDATE `ci_users` SET `User_First_Name` = 'Lendz', `User_Last_Name` = 'App', `User_Email` = 'adam@lendzapp.com', `User_Phone` = '3604478406', `Modified_Date` = '2017-11-27 06:01:32'
WHERE `User_Id` = '75'
ERROR - 2017-11-27 06:19:05 --> Query error: Unknown column 'uf.User_First_Name' in 'field list' - Invalid query: SELECT `m`.*, `uf`.`User_First_Name` AS `From_User_First_Name`, `uf`.`User_Last_Name` AS `From_User_Last_Name`, `uf`.`User_Image` AS `From_User_Image`, `ut`.`User_First_Name` AS `To_User_First_Name`, `ut`.`User_Last_Name` AS `To_User_Last_Name`, `ut`.`User_Image` AS `To_User_Image`, `t`.`Type` as `Tool_Type`, `s`.`Created_By`, `s`.`Subject_Id`, (case when (m.Thread_Type="tool")

             THEN

                  t.Description

             ELSE

                  s.Subject_Name

             END) as Description, (case when (m.Thread_Type="tool")

             THEN

                  t.Archived

             ELSE

                  s.Archived

             END) as Archived
FROM `ci_messages` `m`
LEFT JOIN `ci_users` `uf` ON `uf`.`User_Id`=`m`.`Sent_By`
LEFT JOIN `ci_users` `ut` ON `ut`.`User_Id`=`m`.`Sent_To`
LEFT JOIN `ci_tools` `t` ON `t`.`Id`=`m`.`Thread` AND `m`.`Thread_Type`="tool"
LEFT JOIN `ci_subjects` `s` ON `s`.`Subject_Id`=`m`.`Thread` AND `m`.`Thread_Type`="custom"
WHERE (`Sent_To` = 75 OR `Sent_By` = 75) AND `Last` = "1"
AND ((t.Archived = "0" AND `t`.`User_Id` = "75") OR (`s`.`Archived` = "0" AND `s`.`Created_By` = "75" )  OR  (`t`.`User_Id` != "75") OR (`s`.`Created_With` = "75" ) )
ORDER BY `M_Id` DESC
 LIMIT 10
ERROR - 2017-11-27 06:21:41 --> Query error: Unknown column 'uf.User_First_Name' in 'field list' - Invalid query: SELECT `m`.*, `uf`.`User_First_Name` AS `From_User_First_Name`, `uf`.`User_Last_Name` AS `From_User_Last_Name`, `uf`.`User_Image` AS `From_User_Image`, `ut`.`User_First_Name` AS `To_User_First_Name`, `ut`.`User_Last_Name` AS `To_User_Last_Name`, `ut`.`User_Image` AS `To_User_Image`, `t`.`Type` as `Tool_Type`, `s`.`Created_By`, `s`.`Subject_Id`, (case when (m.Thread_Type="tool")

             THEN

                  t.Description

             ELSE

                  s.Subject_Name

             END) as Description, (case when (m.Thread_Type="tool")

             THEN

                  t.Archived

             ELSE

                  s.Archived

             END) as Archived
FROM `ci_messages` `m`
LEFT JOIN `ci_users` `uf` ON `uf`.`User_Id`=`m`.`Sent_By`
LEFT JOIN `ci_users` `ut` ON `ut`.`User_Id`=`m`.`Sent_To`
LEFT JOIN `ci_tools` `t` ON `t`.`Id`=`m`.`Thread` AND `m`.`Thread_Type`="tool"
LEFT JOIN `ci_subjects` `s` ON `s`.`Subject_Id`=`m`.`Thread` AND `m`.`Thread_Type`="custom"
WHERE (`Sent_To` = 75 OR `Sent_By` = 75) AND `Last` = "1"
AND ((t.Archived = "0" AND `t`.`User_Id` = "75") OR (`s`.`Archived` = "0" AND `s`.`Created_By` = "75" )  OR  (`t`.`User_Id` != "75") OR (`s`.`Created_With` = "75" ) )
ORDER BY `M_Id` DESC
 LIMIT 10
ERROR - 2017-11-27 07:34:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3721) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-11-27 07:34:06 --> Severity: Parsing Error --> syntax error, unexpected '$input' (T_VARIABLE), expecting '(' D:\xampp\htdocs\lendz\dashboard\application\controllers\Users.php 726
ERROR - 2017-11-27 07:34:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3721) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-11-27 07:34:34 --> Severity: Parsing Error --> syntax error, unexpected '$input' (T_VARIABLE), expecting '(' D:\xampp\htdocs\lendz\dashboard\application\controllers\Users.php 726
ERROR - 2017-11-27 07:34:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3721) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-11-27 07:34:35 --> Severity: Parsing Error --> syntax error, unexpected '$input' (T_VARIABLE), expecting '(' D:\xampp\htdocs\lendz\dashboard\application\controllers\Users.php 726
ERROR - 2017-11-27 09:59:26 --> Query error: Unknown column 'Active' in 'where clause' - Invalid query: SELECT *
FROM `ci_categories`
WHERE `Status` = `Active`
ERROR - 2017-11-27 10:01:54 --> Query error: Unknown column 'Active' in 'where clause' - Invalid query: SELECT *
FROM `ci_categories`
WHERE `Status` = `Active`
ERROR - 2017-11-27 10:01:57 --> Query error: Unknown column 'Active' in 'where clause' - Invalid query: SELECT *
FROM `ci_categories`
WHERE `Status` = `Active`
ERROR - 2017-11-27 10:02:13 --> Query error: Unknown column 'Active' in 'where clause' - Invalid query: SELECT *
FROM `ci_categories`
WHERE `Status` = `Active`
ERROR - 2017-11-27 10:25:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3721) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-11-27 10:25:49 --> Severity: Compile Error --> Cannot use isset() on the result of a function call (you can use "null !== func()" instead) D:\xampp\htdocs\lendz\dashboard\application\views\adminlogin\login.php 181
ERROR - 2017-11-27 10:29:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3721) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-11-27 10:29:10 --> Severity: Error --> Call to undefined function delete_cookie() D:\xampp\htdocs\lendz\dashboard\application\controllers\Login.php 189
ERROR - 2017-11-27 10:30:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3721) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-11-27 10:30:36 --> Severity: Error --> Call to undefined function delete_cookie() D:\xampp\htdocs\lendz\dashboard\application\controllers\Login.php 188
ERROR - 2017-11-27 11:02:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\lendz\wp-includes\functions.php:3721) D:\xampp\htdocs\lendz\dashboard\system\core\Common.php 570
ERROR - 2017-11-27 11:02:15 --> Severity: Error --> Cannot use object of type mysqli as array D:\xampp\htdocs\lendz\dashboard\application\views\admin\users_record.php 30
